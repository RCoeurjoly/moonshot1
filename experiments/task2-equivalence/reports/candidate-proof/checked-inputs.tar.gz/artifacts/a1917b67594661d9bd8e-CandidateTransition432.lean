import Task2.Imported.CandidateCuts1
import Task2.Imported.CandidateCuts2
import Task2.Imported.CandidateCuts3
import Task2.Imported.CandidateCuts4
import Task2.Imported.CandidateCuts5
import Task2.Imported.CandidateCuts10
import Task2.Imported.CandidateCuts11
import Task2.Imported.CandidateCuts46
import Task2.Imported.CandidateCuts47
import Task2.Imported.CandidateCuts48
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.CandidateTrace
theorem transition432 (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) :
    Task2.Imported.CandidateAdapter.step (state432 a b raw seedStart) = state433 a b raw seedStart := by
  have h0 : Task2.Imported.CandidateCore.c2lChunk0 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw  = chunk427_0 a b raw seedStart := by
    kernel_exact cut427_0 a b raw seedStart
  have h1 : Task2.Imported.CandidateCore.c2lChunk1 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) = chunk427_1 a b raw seedStart := by
    kernel_exact cut427_1 a b raw seedStart
  have h2 : Task2.Imported.CandidateCore.c2lChunk2 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) = chunk9_2 a b raw seedStart := by
    kernel_exact cut9_2 a b raw seedStart
  have h3 : Task2.Imported.CandidateCore.c2lChunk3 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_2 a b raw seedStart) = chunk10_3 a b raw seedStart := by
    kernel_exact cut10_3 a b raw seedStart
  have h4 : Task2.Imported.CandidateCore.c2lChunk4 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) = chunk11_4 a b raw seedStart := by
    kernel_exact cut11_4 a b raw seedStart
  have h5 : Task2.Imported.CandidateCore.c2lChunk5 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_4 a b raw seedStart) = chunk9_5 a b raw seedStart := by
    kernel_exact cut9_5 a b raw seedStart
  have h6 : Task2.Imported.CandidateCore.c2lChunk6 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) = chunk5_6 a b raw seedStart := by
    kernel_exact cut5_6 a b raw seedStart
  have h7 : Task2.Imported.CandidateCore.c2lChunk7 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) = chunk12_7 a b raw seedStart := by
    kernel_exact cut13_7 a b raw seedStart
  have h8 : Task2.Imported.CandidateCore.c2lChunk8 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) (chunk12_7 a b raw seedStart) = chunk6_8 a b raw seedStart := by
    kernel_exact cut6_8 a b raw seedStart
  have h9 : Task2.Imported.CandidateCore.c2lChunk9 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk6_8 a b raw seedStart) = chunk11_9 a b raw seedStart := by
    kernel_exact cut11_9 a b raw seedStart
  have h10 : Task2.Imported.CandidateCore.c2lChunk10 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk6_8 a b raw seedStart) (chunk11_9 a b raw seedStart) = chunk13_10 a b raw seedStart := by
    kernel_exact cut13_10 a b raw seedStart
  have h11 : Task2.Imported.CandidateCore.c2lChunk11 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) (chunk6_8 a b raw seedStart) (chunk13_10 a b raw seedStart) = chunk432_11 a b raw seedStart := by
    kernel_exact cut432_11 a b raw seedStart
  have h12 : Task2.Imported.CandidateCore.c2lChunk12 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) (chunk432_11 a b raw seedStart) = chunk419_12 a b raw seedStart := by
    kernel_exact cut419_12 a b raw seedStart
  have h13 : Task2.Imported.CandidateCore.c2lChunk13 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk419_12 a b raw seedStart) = chunk14_13 a b raw seedStart := by
    kernel_exact cut14_13 a b raw seedStart
  have h14 : Task2.Imported.CandidateCore.c2lChunk14 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) (chunk6_8 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk14_13 a b raw seedStart) = chunk72_14 a b raw seedStart := by
    kernel_exact cut73_14 a b raw seedStart
  have h15 : Task2.Imported.CandidateCore.c2lChunk15 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk72_14 a b raw seedStart) = chunk418_15 a b raw seedStart := by
    kernel_exact cut418_15 a b raw seedStart
  have h16 : Task2.Imported.CandidateCore.c2lChunk16 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk418_15 a b raw seedStart) = chunk5_16 a b raw seedStart := by
    kernel_exact cut5_16 a b raw seedStart
  have h17 : Task2.Imported.CandidateCore.c2lChunk17 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk10_3 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk5_16 a b raw seedStart) = chunk16_17 a b raw seedStart := by
    kernel_exact cut23_17 a b raw seedStart
  have h18 : Task2.Imported.CandidateCore.c2lChunk18 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_6 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk72_14 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk16_17 a b raw seedStart) = chunk67_18 a b raw seedStart := by
    kernel_exact cut68_18 a b raw seedStart
  have h19 : Task2.Imported.CandidateCore.c2lChunk19 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk16_17 a b raw seedStart) (chunk67_18 a b raw seedStart) = chunk423_19 a b raw seedStart := by
    kernel_exact cut423_19 a b raw seedStart
  have h20 : Task2.Imported.CandidateCore.c2lChunk20 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk16_17 a b raw seedStart) (chunk423_19 a b raw seedStart) = chunk7_20 a b raw seedStart := by
    kernel_exact cut7_20 a b raw seedStart
  have h21 : Task2.Imported.CandidateCore.c2lChunk21 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk16_17 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) = chunk432_21 a b raw seedStart := by
    kernel_exact cut432_21 a b raw seedStart
  have h22 : Task2.Imported.CandidateCore.c2lChunk22 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) = chunk1_22 a b raw seedStart := by
    kernel_exact cut426_22 a b raw seedStart
  have h23 : Task2.Imported.CandidateCore.c2lChunk23 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk72_14 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk67_18 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk1_22 a b raw seedStart) = chunk432_23 a b raw seedStart := by
    kernel_exact cut432_23 a b raw seedStart
  have h24 : Task2.Imported.CandidateCore.c2lChunk24 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_23 a b raw seedStart) = chunk1_24 a b raw seedStart := by
    kernel_exact cut16_24 a b raw seedStart
  have h25 : Task2.Imported.CandidateCore.c2lChunk25 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk16_17 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_24 a b raw seedStart) = chunk1_25 a b raw seedStart := by
    kernel_exact cut10_25 a b raw seedStart
  have h26 : Task2.Imported.CandidateCore.c2lChunk26 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk16_17 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk1_22 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk1_25 a b raw seedStart) = chunk7_26 a b raw seedStart := by
    kernel_exact cut432_26 a b raw seedStart
  have h27 : Task2.Imported.CandidateCore.c2lChunk27 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk1_22 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk7_26 a b raw seedStart) = chunk5_27 a b raw seedStart := by
    kernel_exact cut426_27 a b raw seedStart
  have h28 : Task2.Imported.CandidateCore.c2lChunk28 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk67_18 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk1_22 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk5_27 a b raw seedStart) = chunk432_28 a b raw seedStart := by
    kernel_exact cut432_28 a b raw seedStart
  have h29 : Task2.Imported.CandidateCore.c2lChunk29 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk432_11 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk1_22 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk432_28 a b raw seedStart) = chunk4_29 a b raw seedStart := by
    kernel_exact cut11_29 a b raw seedStart
  have h30 : Task2.Imported.CandidateCore.c2lChunk30 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk7_26 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk4_29 a b raw seedStart) = chunk424_30 a b raw seedStart := by
    kernel_exact cut425_30 a b raw seedStart
  have h31 : Task2.Imported.CandidateCore.c2lChunk31 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk432_28 a b raw seedStart) (chunk4_29 a b raw seedStart) (chunk424_30 a b raw seedStart) = chunk432_31 a b raw seedStart := by
    kernel_exact cut432_31 a b raw seedStart
  have h32 : Task2.Imported.CandidateCore.c2lChunk32 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk4_29 a b raw seedStart) (chunk424_30 a b raw seedStart) (chunk432_31 a b raw seedStart) = chunk1_32 a b raw seedStart := by
    kernel_exact cut4_32 a b raw seedStart
  have h33 : Task2.Imported.CandidateCore.c2lChunk33 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk9_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk424_30 a b raw seedStart) (chunk432_31 a b raw seedStart) (chunk1_32 a b raw seedStart) = chunk24_33 a b raw seedStart := by
    kernel_exact cut425_33 a b raw seedStart
  have h34 : Task2.Imported.CandidateCore.c2lChunk34 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk432_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk424_30 a b raw seedStart) (chunk432_31 a b raw seedStart) (chunk1_32 a b raw seedStart) (chunk24_33 a b raw seedStart) = chunk424_34 a b raw seedStart := by
    kernel_exact cut424_34 a b raw seedStart
  have h35 : Task2.Imported.CandidateCore.c2lChunk35 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk423_19 a b raw seedStart) (chunk7_20 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk424_30 a b raw seedStart) (chunk24_33 a b raw seedStart) (chunk424_34 a b raw seedStart) = chunk426_35 a b raw seedStart := by
    kernel_exact cut427_35 a b raw seedStart
  have h36 : Task2.Imported.CandidateCore.c2lChunk36 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk432_21 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk424_30 a b raw seedStart) (chunk1_32 a b raw seedStart) (chunk24_33 a b raw seedStart) (chunk426_35 a b raw seedStart) = chunk430_36 a b raw seedStart := by
    kernel_exact cut431_36 a b raw seedStart
  have h37 : Task2.Imported.CandidateCore.c2lChunk37 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk419_12 a b raw seedStart) (chunk5_27 a b raw seedStart) (chunk426_35 a b raw seedStart) (chunk430_36 a b raw seedStart) = chunk429_37 a b raw seedStart := by
    kernel_exact cut432_37 a b raw seedStart
  have h38 : Task2.Imported.CandidateCore.c2lChunk38 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk426_35 a b raw seedStart) (chunk430_36 a b raw seedStart) (chunk429_37 a b raw seedStart) = chunk432_38 a b raw seedStart := by
    kernel_exact cut432_38 a b raw seedStart
  have h39 : Task2.Imported.CandidateCore.c2lChunk39 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk426_35 a b raw seedStart) (chunk430_36 a b raw seedStart) (chunk429_37 a b raw seedStart) (chunk432_38 a b raw seedStart) = chunk432_39 a b raw seedStart := by
    kernel_exact cut432_39 a b raw seedStart
  have h40 : Task2.Imported.CandidateCore.c2lChunk40 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk426_35 a b raw seedStart) (chunk430_36 a b raw seedStart) (chunk429_37 a b raw seedStart) (chunk432_38 a b raw seedStart) (chunk432_39 a b raw seedStart) = chunk432_40 a b raw seedStart := by
    kernel_exact cut432_40 a b raw seedStart
  have h41 : Task2.Imported.CandidateCore.c2lChunk41 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk432_38 a b raw seedStart) (chunk432_39 a b raw seedStart) (chunk432_40 a b raw seedStart) = chunk420_41 a b raw seedStart := by
    kernel_exact cut420_41 a b raw seedStart
  have h42 : Task2.Imported.CandidateCore.c2lChunk42 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk432_38 a b raw seedStart) (chunk432_40 a b raw seedStart) (chunk420_41 a b raw seedStart) = chunk422_42 a b raw seedStart := by
    kernel_exact cut422_42 a b raw seedStart
  have h43 : Task2.Imported.CandidateCore.c2lChunk43 (Task2.Imported.CandidateAdapter.inputs (state432 a b raw seedStart)) (state432 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk432_38 a b raw seedStart) (chunk420_41 a b raw seedStart) (chunk422_42 a b raw seedStart) = chunk421_43 a b raw seedStart := by
    kernel_exact cut422_43 a b raw seedStart
  simp only [Task2.Imported.CandidateAdapter.step, Task2.Imported.CandidateCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43]
  kernel_rfl
#print axioms transition432
end Task2.Imported.CandidateTrace
