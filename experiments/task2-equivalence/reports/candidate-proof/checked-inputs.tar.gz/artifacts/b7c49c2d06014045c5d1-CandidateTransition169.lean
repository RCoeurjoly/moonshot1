import Task2.Imported.CandidateCuts1
import Task2.Imported.CandidateCuts2
import Task2.Imported.CandidateCuts4
import Task2.Imported.CandidateCuts7
import Task2.Imported.CandidateCuts8
import Task2.Imported.CandidateCuts18
import Task2.Imported.CandidateCuts19
import Task2.Imported.CandidateCuts20
import Task2.Imported.CandidateCuts21
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.CandidateTrace
theorem transition169 (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) :
    Task2.Imported.CandidateAdapter.step (state169 a b raw seedStart) = state170 a b raw seedStart := by
  have h0 : Task2.Imported.CandidateCore.c2lChunk0 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw  = chunk33_0 a b raw seedStart := by
    kernel_exact cut33_0 a b raw seedStart
  have h1 : Task2.Imported.CandidateCore.c2lChunk1 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) = chunk33_1 a b raw seedStart := by
    kernel_exact cut33_1 a b raw seedStart
  have h2 : Task2.Imported.CandidateCore.c2lChunk2 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) = chunk163_2 a b raw seedStart := by
    kernel_exact cut163_2 a b raw seedStart
  have h3 : Task2.Imported.CandidateCore.c2lChunk3 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk163_2 a b raw seedStart) = chunk161_3 a b raw seedStart := by
    kernel_exact cut161_3 a b raw seedStart
  have h4 : Task2.Imported.CandidateCore.c2lChunk4 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) = chunk162_4 a b raw seedStart := by
    kernel_exact cut162_4 a b raw seedStart
  have h5 : Task2.Imported.CandidateCore.c2lChunk5 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk162_4 a b raw seedStart) = chunk168_5 a b raw seedStart := by
    kernel_exact cut168_5 a b raw seedStart
  have h6 : Task2.Imported.CandidateCore.c2lChunk6 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk162_4 a b raw seedStart) (chunk168_5 a b raw seedStart) = chunk157_6 a b raw seedStart := by
    kernel_exact cut157_6 a b raw seedStart
  have h7 : Task2.Imported.CandidateCore.c2lChunk7 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk162_4 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) = chunk162_7 a b raw seedStart := by
    kernel_exact cut163_7 a b raw seedStart
  have h8 : Task2.Imported.CandidateCore.c2lChunk8 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk162_4 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) (chunk162_7 a b raw seedStart) = chunk158_8 a b raw seedStart := by
    kernel_exact cut158_8 a b raw seedStart
  have h9 : Task2.Imported.CandidateCore.c2lChunk9 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk162_4 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) (chunk162_7 a b raw seedStart) (chunk158_8 a b raw seedStart) = chunk11_9 a b raw seedStart := by
    kernel_exact cut11_9 a b raw seedStart
  have h10 : Task2.Imported.CandidateCore.c2lChunk10 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk162_4 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) (chunk162_7 a b raw seedStart) (chunk158_8 a b raw seedStart) (chunk11_9 a b raw seedStart) = chunk155_10 a b raw seedStart := by
    kernel_exact cut159_10 a b raw seedStart
  have h11 : Task2.Imported.CandidateCore.c2lChunk11 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) (chunk158_8 a b raw seedStart) (chunk155_10 a b raw seedStart) = chunk168_11 a b raw seedStart := by
    kernel_exact cut168_11 a b raw seedStart
  have h12 : Task2.Imported.CandidateCore.c2lChunk12 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk162_4 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) (chunk168_11 a b raw seedStart) = chunk169_12 a b raw seedStart := by
    kernel_exact cut169_12 a b raw seedStart
  have h13 : Task2.Imported.CandidateCore.c2lChunk13 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk162_7 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk155_10 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk169_12 a b raw seedStart) = chunk168_13 a b raw seedStart := by
    kernel_exact cut168_13 a b raw seedStart
  have h14 : Task2.Imported.CandidateCore.c2lChunk14 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) (chunk158_8 a b raw seedStart) (chunk155_10 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk168_13 a b raw seedStart) = chunk168_14 a b raw seedStart := by
    kernel_exact cut168_14 a b raw seedStart
  have h15 : Task2.Imported.CandidateCore.c2lChunk15 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk162_4 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) (chunk162_7 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk168_14 a b raw seedStart) = chunk168_15 a b raw seedStart := by
    kernel_exact cut168_15 a b raw seedStart
  have h16 : Task2.Imported.CandidateCore.c2lChunk16 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk155_10 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk168_13 a b raw seedStart) (chunk168_15 a b raw seedStart) = chunk44_16 a b raw seedStart := by
    kernel_exact cut44_16 a b raw seedStart
  have h17 : Task2.Imported.CandidateCore.c2lChunk17 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk161_3 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk155_10 a b raw seedStart) (chunk168_13 a b raw seedStart) (chunk44_16 a b raw seedStart) = chunk160_17 a b raw seedStart := by
    kernel_exact cut160_17 a b raw seedStart
  have h18 : Task2.Imported.CandidateCore.c2lChunk18 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk157_6 a b raw seedStart) (chunk155_10 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk168_13 a b raw seedStart) (chunk168_14 a b raw seedStart) (chunk168_15 a b raw seedStart) (chunk160_17 a b raw seedStart) = chunk167_18 a b raw seedStart := by
    kernel_exact cut168_18 a b raw seedStart
  have h19 : Task2.Imported.CandidateCore.c2lChunk19 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk168_15 a b raw seedStart) (chunk44_16 a b raw seedStart) (chunk160_17 a b raw seedStart) (chunk167_18 a b raw seedStart) = chunk168_19 a b raw seedStart := by
    kernel_exact cut168_19 a b raw seedStart
  have h20 : Task2.Imported.CandidateCore.c2lChunk20 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk44_16 a b raw seedStart) (chunk160_17 a b raw seedStart) (chunk168_19 a b raw seedStart) = chunk21_20 a b raw seedStart := by
    kernel_exact cut44_20 a b raw seedStart
  have h21 : Task2.Imported.CandidateCore.c2lChunk21 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk168_13 a b raw seedStart) (chunk44_16 a b raw seedStart) (chunk160_17 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) = chunk159_21 a b raw seedStart := by
    kernel_exact cut160_21 a b raw seedStart
  have h22 : Task2.Imported.CandidateCore.c2lChunk22 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk168_15 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) = chunk19_22 a b raw seedStart := by
    kernel_exact cut19_22 a b raw seedStart
  have h23 : Task2.Imported.CandidateCore.c2lChunk23 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk168_14 a b raw seedStart) (chunk168_15 a b raw seedStart) (chunk44_16 a b raw seedStart) (chunk167_18 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk19_22 a b raw seedStart) = chunk169_23 a b raw seedStart := by
    kernel_exact cut169_23 a b raw seedStart
  have h24 : Task2.Imported.CandidateCore.c2lChunk24 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk168_15 a b raw seedStart) (chunk44_16 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk169_23 a b raw seedStart) = chunk44_24 a b raw seedStart := by
    kernel_exact cut44_24 a b raw seedStart
  have h25 : Task2.Imported.CandidateCore.c2lChunk25 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk160_17 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk44_24 a b raw seedStart) = chunk15_25 a b raw seedStart := by
    kernel_exact cut18_25 a b raw seedStart
  have h26 : Task2.Imported.CandidateCore.c2lChunk26 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk44_16 a b raw seedStart) (chunk160_17 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk19_22 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk15_25 a b raw seedStart) = chunk163_26 a b raw seedStart := by
    kernel_exact cut164_26 a b raw seedStart
  have h27 : Task2.Imported.CandidateCore.c2lChunk27 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk19_22 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk163_26 a b raw seedStart) = chunk20_27 a b raw seedStart := by
    kernel_exact cut41_27 a b raw seedStart
  have h28 : Task2.Imported.CandidateCore.c2lChunk28 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk167_18 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk19_22 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk20_27 a b raw seedStart) = chunk169_28 a b raw seedStart := by
    kernel_exact cut169_28 a b raw seedStart
  have h29 : Task2.Imported.CandidateCore.c2lChunk29 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk168_11 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk19_22 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk169_28 a b raw seedStart) = chunk16_29 a b raw seedStart := by
    kernel_exact cut16_29 a b raw seedStart
  have h30 : Task2.Imported.CandidateCore.c2lChunk30 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk44_16 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk163_26 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk16_29 a b raw seedStart) = chunk159_30 a b raw seedStart := by
    kernel_exact cut160_30 a b raw seedStart
  have h31 : Task2.Imported.CandidateCore.c2lChunk31 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk169_28 a b raw seedStart) (chunk16_29 a b raw seedStart) (chunk159_30 a b raw seedStart) = chunk164_31 a b raw seedStart := by
    kernel_exact cut164_31 a b raw seedStart
  have h32 : Task2.Imported.CandidateCore.c2lChunk32 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk44_16 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk16_29 a b raw seedStart) (chunk159_30 a b raw seedStart) (chunk164_31 a b raw seedStart) = chunk1_32 a b raw seedStart := by
    kernel_exact cut4_32 a b raw seedStart
  have h33 : Task2.Imported.CandidateCore.c2lChunk33 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk163_2 a b raw seedStart) (chunk168_5 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk159_30 a b raw seedStart) (chunk164_31 a b raw seedStart) (chunk1_32 a b raw seedStart) = chunk15_33 a b raw seedStart := by
    kernel_exact cut159_33 a b raw seedStart
  have h34 : Task2.Imported.CandidateCore.c2lChunk34 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk169_23 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk159_30 a b raw seedStart) (chunk164_31 a b raw seedStart) (chunk1_32 a b raw seedStart) (chunk15_33 a b raw seedStart) = chunk164_34 a b raw seedStart := by
    kernel_exact cut165_34 a b raw seedStart
  have h35 : Task2.Imported.CandidateCore.c2lChunk35 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk168_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk44_24 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk159_30 a b raw seedStart) (chunk15_33 a b raw seedStart) (chunk164_34 a b raw seedStart) = chunk165_35 a b raw seedStart := by
    kernel_exact cut165_35 a b raw seedStart
  have h36 : Task2.Imported.CandidateCore.c2lChunk36 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_1 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk159_21 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk159_30 a b raw seedStart) (chunk1_32 a b raw seedStart) (chunk15_33 a b raw seedStart) (chunk165_35 a b raw seedStart) = chunk164_36 a b raw seedStart := by
    kernel_exact cut165_36 a b raw seedStart
  have h37 : Task2.Imported.CandidateCore.c2lChunk37 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk169_12 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk165_35 a b raw seedStart) (chunk164_36 a b raw seedStart) = chunk166_37 a b raw seedStart := by
    kernel_exact cut166_37 a b raw seedStart
  have h38 : Task2.Imported.CandidateCore.c2lChunk38 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk165_35 a b raw seedStart) (chunk164_36 a b raw seedStart) (chunk166_37 a b raw seedStart) = chunk167_38 a b raw seedStart := by
    kernel_exact cut167_38 a b raw seedStart
  have h39 : Task2.Imported.CandidateCore.c2lChunk39 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk165_35 a b raw seedStart) (chunk164_36 a b raw seedStart) (chunk166_37 a b raw seedStart) (chunk167_38 a b raw seedStart) = chunk168_39 a b raw seedStart := by
    kernel_exact cut168_39 a b raw seedStart
  have h40 : Task2.Imported.CandidateCore.c2lChunk40 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk165_35 a b raw seedStart) (chunk164_36 a b raw seedStart) (chunk166_37 a b raw seedStart) (chunk167_38 a b raw seedStart) (chunk168_39 a b raw seedStart) = chunk167_40 a b raw seedStart := by
    kernel_exact cut167_40 a b raw seedStart
  have h41 : Task2.Imported.CandidateCore.c2lChunk41 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk167_38 a b raw seedStart) (chunk168_39 a b raw seedStart) (chunk167_40 a b raw seedStart) = chunk169_41 a b raw seedStart := by
    kernel_exact cut169_41 a b raw seedStart
  have h42 : Task2.Imported.CandidateCore.c2lChunk42 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk167_38 a b raw seedStart) (chunk167_40 a b raw seedStart) (chunk169_41 a b raw seedStart) = chunk169_42 a b raw seedStart := by
    kernel_exact cut169_42 a b raw seedStart
  have h43 : Task2.Imported.CandidateCore.c2lChunk43 (Task2.Imported.CandidateAdapter.inputs (state169 a b raw seedStart)) (state169 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk167_38 a b raw seedStart) (chunk169_41 a b raw seedStart) (chunk169_42 a b raw seedStart) = chunk146_43 a b raw seedStart := by
    kernel_exact cut147_43 a b raw seedStart
  simp only [Task2.Imported.CandidateAdapter.step, Task2.Imported.CandidateCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43]
  kernel_rfl
#print axioms transition169
end Task2.Imported.CandidateTrace
