import Mathlib.Tactic.IntervalCases
import Task2.Source
import Task2.Imported.CandidateInitial
import Task2.Imported.CandidateFinalArithmetic
import Task2.Imported.CandidateTransitions0
import Task2.Imported.CandidateTransitions1
import Task2.Imported.CandidateTransitions2
import Task2.Imported.CandidateTransitions3
import Task2.Imported.CandidateTransitions4
import Task2.Imported.CandidateTransitions5
import Task2.Imported.CandidateTransitions6
import Task2.Imported.CandidateTransitions7
import Task2.Imported.CandidateTransitions8
import Task2.Imported.CandidateTransitions9
import Task2.Imported.CandidateTransitions10
import Task2.Imported.CandidateTransitions11
import Task2.Imported.CandidateTransitions12
import Task2.Imported.CandidateTransitions13
import Task2.Imported.CandidateTransitions14
import Task2.Imported.CandidateTransitions15
import Task2.Imported.CandidateTransitions16
import Task2.Imported.CandidateTransitions17
import Task2.Imported.CandidateTransitions18
import Task2.Imported.CandidateTransitions19
import Task2.Imported.CandidateTransitions20
import Task2.Imported.CandidateTransitions21
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.CandidateTrace
noncomputable def traceAt (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) (n : Nat) : Task2.Imported.CandidateAdapter.State :=
  match n with
  | 0 => state0 a b raw seedStart
  | 1 => state1 a b raw seedStart
  | 2 => state2 a b raw seedStart
  | 3 => state3 a b raw seedStart
  | 4 => state4 a b raw seedStart
  | 5 => state5 a b raw seedStart
  | 6 => state6 a b raw seedStart
  | 7 => state7 a b raw seedStart
  | 8 => state8 a b raw seedStart
  | 9 => state9 a b raw seedStart
  | 10 => state10 a b raw seedStart
  | 11 => state11 a b raw seedStart
  | 12 => state12 a b raw seedStart
  | 13 => state13 a b raw seedStart
  | 14 => state14 a b raw seedStart
  | 15 => state15 a b raw seedStart
  | 16 => state16 a b raw seedStart
  | 17 => state17 a b raw seedStart
  | 18 => state18 a b raw seedStart
  | 19 => state19 a b raw seedStart
  | 20 => state20 a b raw seedStart
  | 21 => state21 a b raw seedStart
  | 22 => state22 a b raw seedStart
  | 23 => state23 a b raw seedStart
  | 24 => state24 a b raw seedStart
  | 25 => state25 a b raw seedStart
  | 26 => state26 a b raw seedStart
  | 27 => state27 a b raw seedStart
  | 28 => state28 a b raw seedStart
  | 29 => state29 a b raw seedStart
  | 30 => state30 a b raw seedStart
  | 31 => state31 a b raw seedStart
  | 32 => state32 a b raw seedStart
  | 33 => state33 a b raw seedStart
  | 34 => state34 a b raw seedStart
  | 35 => state35 a b raw seedStart
  | 36 => state36 a b raw seedStart
  | 37 => state37 a b raw seedStart
  | 38 => state38 a b raw seedStart
  | 39 => state39 a b raw seedStart
  | 40 => state40 a b raw seedStart
  | 41 => state41 a b raw seedStart
  | 42 => state42 a b raw seedStart
  | 43 => state43 a b raw seedStart
  | 44 => state44 a b raw seedStart
  | 45 => state45 a b raw seedStart
  | 46 => state46 a b raw seedStart
  | 47 => state47 a b raw seedStart
  | 48 => state48 a b raw seedStart
  | 49 => state49 a b raw seedStart
  | 50 => state50 a b raw seedStart
  | 51 => state51 a b raw seedStart
  | 52 => state52 a b raw seedStart
  | 53 => state53 a b raw seedStart
  | 54 => state54 a b raw seedStart
  | 55 => state55 a b raw seedStart
  | 56 => state56 a b raw seedStart
  | 57 => state57 a b raw seedStart
  | 58 => state58 a b raw seedStart
  | 59 => state59 a b raw seedStart
  | 60 => state60 a b raw seedStart
  | 61 => state61 a b raw seedStart
  | 62 => state62 a b raw seedStart
  | 63 => state63 a b raw seedStart
  | 64 => state64 a b raw seedStart
  | 65 => state65 a b raw seedStart
  | 66 => state66 a b raw seedStart
  | 67 => state67 a b raw seedStart
  | 68 => state68 a b raw seedStart
  | 69 => state69 a b raw seedStart
  | 70 => state70 a b raw seedStart
  | 71 => state71 a b raw seedStart
  | 72 => state72 a b raw seedStart
  | 73 => state73 a b raw seedStart
  | 74 => state74 a b raw seedStart
  | 75 => state75 a b raw seedStart
  | 76 => state76 a b raw seedStart
  | 77 => state77 a b raw seedStart
  | 78 => state78 a b raw seedStart
  | 79 => state79 a b raw seedStart
  | 80 => state80 a b raw seedStart
  | 81 => state81 a b raw seedStart
  | 82 => state82 a b raw seedStart
  | 83 => state83 a b raw seedStart
  | 84 => state84 a b raw seedStart
  | 85 => state85 a b raw seedStart
  | 86 => state86 a b raw seedStart
  | 87 => state87 a b raw seedStart
  | 88 => state88 a b raw seedStart
  | 89 => state89 a b raw seedStart
  | 90 => state90 a b raw seedStart
  | 91 => state91 a b raw seedStart
  | 92 => state92 a b raw seedStart
  | 93 => state93 a b raw seedStart
  | 94 => state94 a b raw seedStart
  | 95 => state95 a b raw seedStart
  | 96 => state96 a b raw seedStart
  | 97 => state97 a b raw seedStart
  | 98 => state98 a b raw seedStart
  | 99 => state99 a b raw seedStart
  | 100 => state100 a b raw seedStart
  | 101 => state101 a b raw seedStart
  | 102 => state102 a b raw seedStart
  | 103 => state103 a b raw seedStart
  | 104 => state104 a b raw seedStart
  | 105 => state105 a b raw seedStart
  | 106 => state106 a b raw seedStart
  | 107 => state107 a b raw seedStart
  | 108 => state108 a b raw seedStart
  | 109 => state109 a b raw seedStart
  | 110 => state110 a b raw seedStart
  | 111 => state111 a b raw seedStart
  | 112 => state112 a b raw seedStart
  | 113 => state113 a b raw seedStart
  | 114 => state114 a b raw seedStart
  | 115 => state115 a b raw seedStart
  | 116 => state116 a b raw seedStart
  | 117 => state117 a b raw seedStart
  | 118 => state118 a b raw seedStart
  | 119 => state119 a b raw seedStart
  | 120 => state120 a b raw seedStart
  | 121 => state121 a b raw seedStart
  | 122 => state122 a b raw seedStart
  | 123 => state123 a b raw seedStart
  | 124 => state124 a b raw seedStart
  | 125 => state125 a b raw seedStart
  | 126 => state126 a b raw seedStart
  | 127 => state127 a b raw seedStart
  | 128 => state128 a b raw seedStart
  | 129 => state129 a b raw seedStart
  | 130 => state130 a b raw seedStart
  | 131 => state131 a b raw seedStart
  | 132 => state132 a b raw seedStart
  | 133 => state133 a b raw seedStart
  | 134 => state134 a b raw seedStart
  | 135 => state135 a b raw seedStart
  | 136 => state136 a b raw seedStart
  | 137 => state137 a b raw seedStart
  | 138 => state138 a b raw seedStart
  | 139 => state139 a b raw seedStart
  | 140 => state140 a b raw seedStart
  | 141 => state141 a b raw seedStart
  | 142 => state142 a b raw seedStart
  | 143 => state143 a b raw seedStart
  | 144 => state144 a b raw seedStart
  | 145 => state145 a b raw seedStart
  | 146 => state146 a b raw seedStart
  | 147 => state147 a b raw seedStart
  | 148 => state148 a b raw seedStart
  | 149 => state149 a b raw seedStart
  | 150 => state150 a b raw seedStart
  | 151 => state151 a b raw seedStart
  | 152 => state152 a b raw seedStart
  | 153 => state153 a b raw seedStart
  | 154 => state154 a b raw seedStart
  | 155 => state155 a b raw seedStart
  | 156 => state156 a b raw seedStart
  | 157 => state157 a b raw seedStart
  | 158 => state158 a b raw seedStart
  | 159 => state159 a b raw seedStart
  | 160 => state160 a b raw seedStart
  | 161 => state161 a b raw seedStart
  | 162 => state162 a b raw seedStart
  | 163 => state163 a b raw seedStart
  | 164 => state164 a b raw seedStart
  | 165 => state165 a b raw seedStart
  | 166 => state166 a b raw seedStart
  | 167 => state167 a b raw seedStart
  | 168 => state168 a b raw seedStart
  | 169 => state169 a b raw seedStart
  | 170 => state170 a b raw seedStart
  | 171 => state171 a b raw seedStart
  | 172 => state172 a b raw seedStart
  | 173 => state173 a b raw seedStart
  | 174 => state174 a b raw seedStart
  | 175 => state175 a b raw seedStart
  | 176 => state176 a b raw seedStart
  | 177 => state177 a b raw seedStart
  | 178 => state178 a b raw seedStart
  | 179 => state179 a b raw seedStart
  | 180 => state180 a b raw seedStart
  | 181 => state181 a b raw seedStart
  | 182 => state182 a b raw seedStart
  | 183 => state183 a b raw seedStart
  | 184 => state184 a b raw seedStart
  | 185 => state185 a b raw seedStart
  | 186 => state186 a b raw seedStart
  | 187 => state187 a b raw seedStart
  | 188 => state188 a b raw seedStart
  | 189 => state189 a b raw seedStart
  | 190 => state190 a b raw seedStart
  | 191 => state191 a b raw seedStart
  | 192 => state192 a b raw seedStart
  | 193 => state193 a b raw seedStart
  | 194 => state194 a b raw seedStart
  | 195 => state195 a b raw seedStart
  | 196 => state196 a b raw seedStart
  | 197 => state197 a b raw seedStart
  | 198 => state198 a b raw seedStart
  | 199 => state199 a b raw seedStart
  | 200 => state200 a b raw seedStart
  | 201 => state201 a b raw seedStart
  | 202 => state202 a b raw seedStart
  | 203 => state203 a b raw seedStart
  | 204 => state204 a b raw seedStart
  | 205 => state205 a b raw seedStart
  | 206 => state206 a b raw seedStart
  | 207 => state207 a b raw seedStart
  | 208 => state208 a b raw seedStart
  | 209 => state209 a b raw seedStart
  | 210 => state210 a b raw seedStart
  | 211 => state211 a b raw seedStart
  | 212 => state212 a b raw seedStart
  | 213 => state213 a b raw seedStart
  | 214 => state214 a b raw seedStart
  | 215 => state215 a b raw seedStart
  | 216 => state216 a b raw seedStart
  | 217 => state217 a b raw seedStart
  | 218 => state218 a b raw seedStart
  | 219 => state219 a b raw seedStart
  | 220 => state220 a b raw seedStart
  | 221 => state221 a b raw seedStart
  | 222 => state222 a b raw seedStart
  | 223 => state223 a b raw seedStart
  | 224 => state224 a b raw seedStart
  | 225 => state225 a b raw seedStart
  | 226 => state226 a b raw seedStart
  | 227 => state227 a b raw seedStart
  | 228 => state228 a b raw seedStart
  | 229 => state229 a b raw seedStart
  | 230 => state230 a b raw seedStart
  | 231 => state231 a b raw seedStart
  | 232 => state232 a b raw seedStart
  | 233 => state233 a b raw seedStart
  | 234 => state234 a b raw seedStart
  | 235 => state235 a b raw seedStart
  | 236 => state236 a b raw seedStart
  | 237 => state237 a b raw seedStart
  | 238 => state238 a b raw seedStart
  | 239 => state239 a b raw seedStart
  | 240 => state240 a b raw seedStart
  | 241 => state241 a b raw seedStart
  | 242 => state242 a b raw seedStart
  | 243 => state243 a b raw seedStart
  | 244 => state244 a b raw seedStart
  | 245 => state245 a b raw seedStart
  | 246 => state246 a b raw seedStart
  | 247 => state247 a b raw seedStart
  | 248 => state248 a b raw seedStart
  | 249 => state249 a b raw seedStart
  | 250 => state250 a b raw seedStart
  | 251 => state251 a b raw seedStart
  | 252 => state252 a b raw seedStart
  | 253 => state253 a b raw seedStart
  | 254 => state254 a b raw seedStart
  | 255 => state255 a b raw seedStart
  | 256 => state256 a b raw seedStart
  | 257 => state257 a b raw seedStart
  | 258 => state258 a b raw seedStart
  | 259 => state259 a b raw seedStart
  | 260 => state260 a b raw seedStart
  | 261 => state261 a b raw seedStart
  | 262 => state262 a b raw seedStart
  | 263 => state263 a b raw seedStart
  | 264 => state264 a b raw seedStart
  | 265 => state265 a b raw seedStart
  | 266 => state266 a b raw seedStart
  | 267 => state267 a b raw seedStart
  | 268 => state268 a b raw seedStart
  | 269 => state269 a b raw seedStart
  | 270 => state270 a b raw seedStart
  | 271 => state271 a b raw seedStart
  | 272 => state272 a b raw seedStart
  | 273 => state273 a b raw seedStart
  | 274 => state274 a b raw seedStart
  | 275 => state275 a b raw seedStart
  | 276 => state276 a b raw seedStart
  | 277 => state277 a b raw seedStart
  | 278 => state278 a b raw seedStart
  | 279 => state279 a b raw seedStart
  | 280 => state280 a b raw seedStart
  | 281 => state281 a b raw seedStart
  | 282 => state282 a b raw seedStart
  | 283 => state283 a b raw seedStart
  | 284 => state284 a b raw seedStart
  | 285 => state285 a b raw seedStart
  | 286 => state286 a b raw seedStart
  | 287 => state287 a b raw seedStart
  | 288 => state288 a b raw seedStart
  | 289 => state289 a b raw seedStart
  | 290 => state290 a b raw seedStart
  | 291 => state291 a b raw seedStart
  | 292 => state292 a b raw seedStart
  | 293 => state293 a b raw seedStart
  | 294 => state294 a b raw seedStart
  | 295 => state295 a b raw seedStart
  | 296 => state296 a b raw seedStart
  | 297 => state297 a b raw seedStart
  | 298 => state298 a b raw seedStart
  | 299 => state299 a b raw seedStart
  | 300 => state300 a b raw seedStart
  | 301 => state301 a b raw seedStart
  | 302 => state302 a b raw seedStart
  | 303 => state303 a b raw seedStart
  | 304 => state304 a b raw seedStart
  | 305 => state305 a b raw seedStart
  | 306 => state306 a b raw seedStart
  | 307 => state307 a b raw seedStart
  | 308 => state308 a b raw seedStart
  | 309 => state309 a b raw seedStart
  | 310 => state310 a b raw seedStart
  | 311 => state311 a b raw seedStart
  | 312 => state312 a b raw seedStart
  | 313 => state313 a b raw seedStart
  | 314 => state314 a b raw seedStart
  | 315 => state315 a b raw seedStart
  | 316 => state316 a b raw seedStart
  | 317 => state317 a b raw seedStart
  | 318 => state318 a b raw seedStart
  | 319 => state319 a b raw seedStart
  | 320 => state320 a b raw seedStart
  | 321 => state321 a b raw seedStart
  | 322 => state322 a b raw seedStart
  | 323 => state323 a b raw seedStart
  | 324 => state324 a b raw seedStart
  | 325 => state325 a b raw seedStart
  | 326 => state326 a b raw seedStart
  | 327 => state327 a b raw seedStart
  | 328 => state328 a b raw seedStart
  | 329 => state329 a b raw seedStart
  | 330 => state330 a b raw seedStart
  | 331 => state331 a b raw seedStart
  | 332 => state332 a b raw seedStart
  | 333 => state333 a b raw seedStart
  | 334 => state334 a b raw seedStart
  | 335 => state335 a b raw seedStart
  | 336 => state336 a b raw seedStart
  | 337 => state337 a b raw seedStart
  | 338 => state338 a b raw seedStart
  | 339 => state339 a b raw seedStart
  | 340 => state340 a b raw seedStart
  | 341 => state341 a b raw seedStart
  | 342 => state342 a b raw seedStart
  | 343 => state343 a b raw seedStart
  | 344 => state344 a b raw seedStart
  | 345 => state345 a b raw seedStart
  | 346 => state346 a b raw seedStart
  | 347 => state347 a b raw seedStart
  | 348 => state348 a b raw seedStart
  | 349 => state349 a b raw seedStart
  | 350 => state350 a b raw seedStart
  | 351 => state351 a b raw seedStart
  | 352 => state352 a b raw seedStart
  | 353 => state353 a b raw seedStart
  | 354 => state354 a b raw seedStart
  | 355 => state355 a b raw seedStart
  | 356 => state356 a b raw seedStart
  | 357 => state357 a b raw seedStart
  | 358 => state358 a b raw seedStart
  | 359 => state359 a b raw seedStart
  | 360 => state360 a b raw seedStart
  | 361 => state361 a b raw seedStart
  | 362 => state362 a b raw seedStart
  | 363 => state363 a b raw seedStart
  | 364 => state364 a b raw seedStart
  | 365 => state365 a b raw seedStart
  | 366 => state366 a b raw seedStart
  | 367 => state367 a b raw seedStart
  | 368 => state368 a b raw seedStart
  | 369 => state369 a b raw seedStart
  | 370 => state370 a b raw seedStart
  | 371 => state371 a b raw seedStart
  | 372 => state372 a b raw seedStart
  | 373 => state373 a b raw seedStart
  | 374 => state374 a b raw seedStart
  | 375 => state375 a b raw seedStart
  | 376 => state376 a b raw seedStart
  | 377 => state377 a b raw seedStart
  | 378 => state378 a b raw seedStart
  | 379 => state379 a b raw seedStart
  | 380 => state380 a b raw seedStart
  | 381 => state381 a b raw seedStart
  | 382 => state382 a b raw seedStart
  | 383 => state383 a b raw seedStart
  | 384 => state384 a b raw seedStart
  | 385 => state385 a b raw seedStart
  | 386 => state386 a b raw seedStart
  | 387 => state387 a b raw seedStart
  | 388 => state388 a b raw seedStart
  | 389 => state389 a b raw seedStart
  | 390 => state390 a b raw seedStart
  | 391 => state391 a b raw seedStart
  | 392 => state392 a b raw seedStart
  | 393 => state393 a b raw seedStart
  | 394 => state394 a b raw seedStart
  | 395 => state395 a b raw seedStart
  | 396 => state396 a b raw seedStart
  | 397 => state397 a b raw seedStart
  | 398 => state398 a b raw seedStart
  | 399 => state399 a b raw seedStart
  | 400 => state400 a b raw seedStart
  | 401 => state401 a b raw seedStart
  | 402 => state402 a b raw seedStart
  | 403 => state403 a b raw seedStart
  | 404 => state404 a b raw seedStart
  | 405 => state405 a b raw seedStart
  | 406 => state406 a b raw seedStart
  | 407 => state407 a b raw seedStart
  | 408 => state408 a b raw seedStart
  | 409 => state409 a b raw seedStart
  | 410 => state410 a b raw seedStart
  | 411 => state411 a b raw seedStart
  | 412 => state412 a b raw seedStart
  | 413 => state413 a b raw seedStart
  | 414 => state414 a b raw seedStart
  | 415 => state415 a b raw seedStart
  | 416 => state416 a b raw seedStart
  | 417 => state417 a b raw seedStart
  | 418 => state418 a b raw seedStart
  | 419 => state419 a b raw seedStart
  | 420 => state420 a b raw seedStart
  | 421 => state421 a b raw seedStart
  | 422 => state422 a b raw seedStart
  | 423 => state423 a b raw seedStart
  | 424 => state424 a b raw seedStart
  | 425 => state425 a b raw seedStart
  | 426 => state426 a b raw seedStart
  | 427 => state427 a b raw seedStart
  | 428 => state428 a b raw seedStart
  | 429 => state429 a b raw seedStart
  | 430 => state430 a b raw seedStart
  | 431 => state431 a b raw seedStart
  | 432 => state432 a b raw seedStart
  | 433 => state433 a b raw seedStart
  | 434 => state434 a b raw seedStart
  | 435 => state435 a b raw seedStart
  | _ => state436 a b raw seedStart
theorem first_result (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) : Task2.FirstResult Task2.Imported.candidate (state0 a b raw seedStart) 436 (Task2.dot32 a b) := by
  apply Task2.firstResult_of_trace Task2.Imported.candidate (traceAt a b raw seedStart) 436 (Task2.dot32 a b)
  · intro n hn
    interval_cases n
    · exact transition0 a b raw seedStart
    · exact transition1 a b raw seedStart
    · exact transition2 a b raw seedStart
    · exact transition3 a b raw seedStart
    · exact transition4 a b raw seedStart
    · exact transition5 a b raw seedStart
    · exact transition6 a b raw seedStart
    · exact transition7 a b raw seedStart
    · exact transition8 a b raw seedStart
    · exact transition9 a b raw seedStart
    · exact transition10 a b raw seedStart
    · exact transition11 a b raw seedStart
    · exact transition12 a b raw seedStart
    · exact transition13 a b raw seedStart
    · exact transition14 a b raw seedStart
    · exact transition15 a b raw seedStart
    · exact transition16 a b raw seedStart
    · exact transition17 a b raw seedStart
    · exact transition18 a b raw seedStart
    · exact transition19 a b raw seedStart
    · exact transition20 a b raw seedStart
    · exact transition21 a b raw seedStart
    · exact transition22 a b raw seedStart
    · exact transition23 a b raw seedStart
    · exact transition24 a b raw seedStart
    · exact transition25 a b raw seedStart
    · exact transition26 a b raw seedStart
    · exact transition27 a b raw seedStart
    · exact transition28 a b raw seedStart
    · exact transition29 a b raw seedStart
    · exact transition30 a b raw seedStart
    · exact transition31 a b raw seedStart
    · exact transition32 a b raw seedStart
    · exact transition33 a b raw seedStart
    · exact transition34 a b raw seedStart
    · exact transition35 a b raw seedStart
    · exact transition36 a b raw seedStart
    · exact transition37 a b raw seedStart
    · exact transition38 a b raw seedStart
    · exact transition39 a b raw seedStart
    · exact transition40 a b raw seedStart
    · exact transition41 a b raw seedStart
    · exact transition42 a b raw seedStart
    · exact transition43 a b raw seedStart
    · exact transition44 a b raw seedStart
    · exact transition45 a b raw seedStart
    · exact transition46 a b raw seedStart
    · exact transition47 a b raw seedStart
    · exact transition48 a b raw seedStart
    · exact transition49 a b raw seedStart
    · exact transition50 a b raw seedStart
    · exact transition51 a b raw seedStart
    · exact transition52 a b raw seedStart
    · exact transition53 a b raw seedStart
    · exact transition54 a b raw seedStart
    · exact transition55 a b raw seedStart
    · exact transition56 a b raw seedStart
    · exact transition57 a b raw seedStart
    · exact transition58 a b raw seedStart
    · exact transition59 a b raw seedStart
    · exact transition60 a b raw seedStart
    · exact transition61 a b raw seedStart
    · exact transition62 a b raw seedStart
    · exact transition63 a b raw seedStart
    · exact transition64 a b raw seedStart
    · exact transition65 a b raw seedStart
    · exact transition66 a b raw seedStart
    · exact transition67 a b raw seedStart
    · exact transition68 a b raw seedStart
    · exact transition69 a b raw seedStart
    · exact transition70 a b raw seedStart
    · exact transition71 a b raw seedStart
    · exact transition72 a b raw seedStart
    · exact transition73 a b raw seedStart
    · exact transition74 a b raw seedStart
    · exact transition75 a b raw seedStart
    · exact transition76 a b raw seedStart
    · exact transition77 a b raw seedStart
    · exact transition78 a b raw seedStart
    · exact transition79 a b raw seedStart
    · exact transition80 a b raw seedStart
    · exact transition81 a b raw seedStart
    · exact transition82 a b raw seedStart
    · exact transition83 a b raw seedStart
    · exact transition84 a b raw seedStart
    · exact transition85 a b raw seedStart
    · exact transition86 a b raw seedStart
    · exact transition87 a b raw seedStart
    · exact transition88 a b raw seedStart
    · exact transition89 a b raw seedStart
    · exact transition90 a b raw seedStart
    · exact transition91 a b raw seedStart
    · exact transition92 a b raw seedStart
    · exact transition93 a b raw seedStart
    · exact transition94 a b raw seedStart
    · exact transition95 a b raw seedStart
    · exact transition96 a b raw seedStart
    · exact transition97 a b raw seedStart
    · exact transition98 a b raw seedStart
    · exact transition99 a b raw seedStart
    · exact transition100 a b raw seedStart
    · exact transition101 a b raw seedStart
    · exact transition102 a b raw seedStart
    · exact transition103 a b raw seedStart
    · exact transition104 a b raw seedStart
    · exact transition105 a b raw seedStart
    · exact transition106 a b raw seedStart
    · exact transition107 a b raw seedStart
    · exact transition108 a b raw seedStart
    · exact transition109 a b raw seedStart
    · exact transition110 a b raw seedStart
    · exact transition111 a b raw seedStart
    · exact transition112 a b raw seedStart
    · exact transition113 a b raw seedStart
    · exact transition114 a b raw seedStart
    · exact transition115 a b raw seedStart
    · exact transition116 a b raw seedStart
    · exact transition117 a b raw seedStart
    · exact transition118 a b raw seedStart
    · exact transition119 a b raw seedStart
    · exact transition120 a b raw seedStart
    · exact transition121 a b raw seedStart
    · exact transition122 a b raw seedStart
    · exact transition123 a b raw seedStart
    · exact transition124 a b raw seedStart
    · exact transition125 a b raw seedStart
    · exact transition126 a b raw seedStart
    · exact transition127 a b raw seedStart
    · exact transition128 a b raw seedStart
    · exact transition129 a b raw seedStart
    · exact transition130 a b raw seedStart
    · exact transition131 a b raw seedStart
    · exact transition132 a b raw seedStart
    · exact transition133 a b raw seedStart
    · exact transition134 a b raw seedStart
    · exact transition135 a b raw seedStart
    · exact transition136 a b raw seedStart
    · exact transition137 a b raw seedStart
    · exact transition138 a b raw seedStart
    · exact transition139 a b raw seedStart
    · exact transition140 a b raw seedStart
    · exact transition141 a b raw seedStart
    · exact transition142 a b raw seedStart
    · exact transition143 a b raw seedStart
    · exact transition144 a b raw seedStart
    · exact transition145 a b raw seedStart
    · exact transition146 a b raw seedStart
    · exact transition147 a b raw seedStart
    · exact transition148 a b raw seedStart
    · exact transition149 a b raw seedStart
    · exact transition150 a b raw seedStart
    · exact transition151 a b raw seedStart
    · exact transition152 a b raw seedStart
    · exact transition153 a b raw seedStart
    · exact transition154 a b raw seedStart
    · exact transition155 a b raw seedStart
    · exact transition156 a b raw seedStart
    · exact transition157 a b raw seedStart
    · exact transition158 a b raw seedStart
    · exact transition159 a b raw seedStart
    · exact transition160 a b raw seedStart
    · exact transition161 a b raw seedStart
    · exact transition162 a b raw seedStart
    · exact transition163 a b raw seedStart
    · exact transition164 a b raw seedStart
    · exact transition165 a b raw seedStart
    · exact transition166 a b raw seedStart
    · exact transition167 a b raw seedStart
    · exact transition168 a b raw seedStart
    · exact transition169 a b raw seedStart
    · exact transition170 a b raw seedStart
    · exact transition171 a b raw seedStart
    · exact transition172 a b raw seedStart
    · exact transition173 a b raw seedStart
    · exact transition174 a b raw seedStart
    · exact transition175 a b raw seedStart
    · exact transition176 a b raw seedStart
    · exact transition177 a b raw seedStart
    · exact transition178 a b raw seedStart
    · exact transition179 a b raw seedStart
    · exact transition180 a b raw seedStart
    · exact transition181 a b raw seedStart
    · exact transition182 a b raw seedStart
    · exact transition183 a b raw seedStart
    · exact transition184 a b raw seedStart
    · exact transition185 a b raw seedStart
    · exact transition186 a b raw seedStart
    · exact transition187 a b raw seedStart
    · exact transition188 a b raw seedStart
    · exact transition189 a b raw seedStart
    · exact transition190 a b raw seedStart
    · exact transition191 a b raw seedStart
    · exact transition192 a b raw seedStart
    · exact transition193 a b raw seedStart
    · exact transition194 a b raw seedStart
    · exact transition195 a b raw seedStart
    · exact transition196 a b raw seedStart
    · exact transition197 a b raw seedStart
    · exact transition198 a b raw seedStart
    · exact transition199 a b raw seedStart
    · exact transition200 a b raw seedStart
    · exact transition201 a b raw seedStart
    · exact transition202 a b raw seedStart
    · exact transition203 a b raw seedStart
    · exact transition204 a b raw seedStart
    · exact transition205 a b raw seedStart
    · exact transition206 a b raw seedStart
    · exact transition207 a b raw seedStart
    · exact transition208 a b raw seedStart
    · exact transition209 a b raw seedStart
    · exact transition210 a b raw seedStart
    · exact transition211 a b raw seedStart
    · exact transition212 a b raw seedStart
    · exact transition213 a b raw seedStart
    · exact transition214 a b raw seedStart
    · exact transition215 a b raw seedStart
    · exact transition216 a b raw seedStart
    · exact transition217 a b raw seedStart
    · exact transition218 a b raw seedStart
    · exact transition219 a b raw seedStart
    · exact transition220 a b raw seedStart
    · exact transition221 a b raw seedStart
    · exact transition222 a b raw seedStart
    · exact transition223 a b raw seedStart
    · exact transition224 a b raw seedStart
    · exact transition225 a b raw seedStart
    · exact transition226 a b raw seedStart
    · exact transition227 a b raw seedStart
    · exact transition228 a b raw seedStart
    · exact transition229 a b raw seedStart
    · exact transition230 a b raw seedStart
    · exact transition231 a b raw seedStart
    · exact transition232 a b raw seedStart
    · exact transition233 a b raw seedStart
    · exact transition234 a b raw seedStart
    · exact transition235 a b raw seedStart
    · exact transition236 a b raw seedStart
    · exact transition237 a b raw seedStart
    · exact transition238 a b raw seedStart
    · exact transition239 a b raw seedStart
    · exact transition240 a b raw seedStart
    · exact transition241 a b raw seedStart
    · exact transition242 a b raw seedStart
    · exact transition243 a b raw seedStart
    · exact transition244 a b raw seedStart
    · exact transition245 a b raw seedStart
    · exact transition246 a b raw seedStart
    · exact transition247 a b raw seedStart
    · exact transition248 a b raw seedStart
    · exact transition249 a b raw seedStart
    · exact transition250 a b raw seedStart
    · exact transition251 a b raw seedStart
    · exact transition252 a b raw seedStart
    · exact transition253 a b raw seedStart
    · exact transition254 a b raw seedStart
    · exact transition255 a b raw seedStart
    · exact transition256 a b raw seedStart
    · exact transition257 a b raw seedStart
    · exact transition258 a b raw seedStart
    · exact transition259 a b raw seedStart
    · exact transition260 a b raw seedStart
    · exact transition261 a b raw seedStart
    · exact transition262 a b raw seedStart
    · exact transition263 a b raw seedStart
    · exact transition264 a b raw seedStart
    · exact transition265 a b raw seedStart
    · exact transition266 a b raw seedStart
    · exact transition267 a b raw seedStart
    · exact transition268 a b raw seedStart
    · exact transition269 a b raw seedStart
    · exact transition270 a b raw seedStart
    · exact transition271 a b raw seedStart
    · exact transition272 a b raw seedStart
    · exact transition273 a b raw seedStart
    · exact transition274 a b raw seedStart
    · exact transition275 a b raw seedStart
    · exact transition276 a b raw seedStart
    · exact transition277 a b raw seedStart
    · exact transition278 a b raw seedStart
    · exact transition279 a b raw seedStart
    · exact transition280 a b raw seedStart
    · exact transition281 a b raw seedStart
    · exact transition282 a b raw seedStart
    · exact transition283 a b raw seedStart
    · exact transition284 a b raw seedStart
    · exact transition285 a b raw seedStart
    · exact transition286 a b raw seedStart
    · exact transition287 a b raw seedStart
    · exact transition288 a b raw seedStart
    · exact transition289 a b raw seedStart
    · exact transition290 a b raw seedStart
    · exact transition291 a b raw seedStart
    · exact transition292 a b raw seedStart
    · exact transition293 a b raw seedStart
    · exact transition294 a b raw seedStart
    · exact transition295 a b raw seedStart
    · exact transition296 a b raw seedStart
    · exact transition297 a b raw seedStart
    · exact transition298 a b raw seedStart
    · exact transition299 a b raw seedStart
    · exact transition300 a b raw seedStart
    · exact transition301 a b raw seedStart
    · exact transition302 a b raw seedStart
    · exact transition303 a b raw seedStart
    · exact transition304 a b raw seedStart
    · exact transition305 a b raw seedStart
    · exact transition306 a b raw seedStart
    · exact transition307 a b raw seedStart
    · exact transition308 a b raw seedStart
    · exact transition309 a b raw seedStart
    · exact transition310 a b raw seedStart
    · exact transition311 a b raw seedStart
    · exact transition312 a b raw seedStart
    · exact transition313 a b raw seedStart
    · exact transition314 a b raw seedStart
    · exact transition315 a b raw seedStart
    · exact transition316 a b raw seedStart
    · exact transition317 a b raw seedStart
    · exact transition318 a b raw seedStart
    · exact transition319 a b raw seedStart
    · exact transition320 a b raw seedStart
    · exact transition321 a b raw seedStart
    · exact transition322 a b raw seedStart
    · exact transition323 a b raw seedStart
    · exact transition324 a b raw seedStart
    · exact transition325 a b raw seedStart
    · exact transition326 a b raw seedStart
    · exact transition327 a b raw seedStart
    · exact transition328 a b raw seedStart
    · exact transition329 a b raw seedStart
    · exact transition330 a b raw seedStart
    · exact transition331 a b raw seedStart
    · exact transition332 a b raw seedStart
    · exact transition333 a b raw seedStart
    · exact transition334 a b raw seedStart
    · exact transition335 a b raw seedStart
    · exact transition336 a b raw seedStart
    · exact transition337 a b raw seedStart
    · exact transition338 a b raw seedStart
    · exact transition339 a b raw seedStart
    · exact transition340 a b raw seedStart
    · exact transition341 a b raw seedStart
    · exact transition342 a b raw seedStart
    · exact transition343 a b raw seedStart
    · exact transition344 a b raw seedStart
    · exact transition345 a b raw seedStart
    · exact transition346 a b raw seedStart
    · exact transition347 a b raw seedStart
    · exact transition348 a b raw seedStart
    · exact transition349 a b raw seedStart
    · exact transition350 a b raw seedStart
    · exact transition351 a b raw seedStart
    · exact transition352 a b raw seedStart
    · exact transition353 a b raw seedStart
    · exact transition354 a b raw seedStart
    · exact transition355 a b raw seedStart
    · exact transition356 a b raw seedStart
    · exact transition357 a b raw seedStart
    · exact transition358 a b raw seedStart
    · exact transition359 a b raw seedStart
    · exact transition360 a b raw seedStart
    · exact transition361 a b raw seedStart
    · exact transition362 a b raw seedStart
    · exact transition363 a b raw seedStart
    · exact transition364 a b raw seedStart
    · exact transition365 a b raw seedStart
    · exact transition366 a b raw seedStart
    · exact transition367 a b raw seedStart
    · exact transition368 a b raw seedStart
    · exact transition369 a b raw seedStart
    · exact transition370 a b raw seedStart
    · exact transition371 a b raw seedStart
    · exact transition372 a b raw seedStart
    · exact transition373 a b raw seedStart
    · exact transition374 a b raw seedStart
    · exact transition375 a b raw seedStart
    · exact transition376 a b raw seedStart
    · exact transition377 a b raw seedStart
    · exact transition378 a b raw seedStart
    · exact transition379 a b raw seedStart
    · exact transition380 a b raw seedStart
    · exact transition381 a b raw seedStart
    · exact transition382 a b raw seedStart
    · exact transition383 a b raw seedStart
    · exact transition384 a b raw seedStart
    · exact transition385 a b raw seedStart
    · exact transition386 a b raw seedStart
    · exact transition387 a b raw seedStart
    · exact transition388 a b raw seedStart
    · exact transition389 a b raw seedStart
    · exact transition390 a b raw seedStart
    · exact transition391 a b raw seedStart
    · exact transition392 a b raw seedStart
    · exact transition393 a b raw seedStart
    · exact transition394 a b raw seedStart
    · exact transition395 a b raw seedStart
    · exact transition396 a b raw seedStart
    · exact transition397 a b raw seedStart
    · exact transition398 a b raw seedStart
    · exact transition399 a b raw seedStart
    · exact transition400 a b raw seedStart
    · exact transition401 a b raw seedStart
    · exact transition402 a b raw seedStart
    · exact transition403 a b raw seedStart
    · exact transition404 a b raw seedStart
    · exact transition405 a b raw seedStart
    · exact transition406 a b raw seedStart
    · exact transition407 a b raw seedStart
    · exact transition408 a b raw seedStart
    · exact transition409 a b raw seedStart
    · exact transition410 a b raw seedStart
    · exact transition411 a b raw seedStart
    · exact transition412 a b raw seedStart
    · exact transition413 a b raw seedStart
    · exact transition414 a b raw seedStart
    · exact transition415 a b raw seedStart
    · exact transition416 a b raw seedStart
    · exact transition417 a b raw seedStart
    · exact transition418 a b raw seedStart
    · exact transition419 a b raw seedStart
    · exact transition420 a b raw seedStart
    · exact transition421 a b raw seedStart
    · exact transition422 a b raw seedStart
    · exact transition423 a b raw seedStart
    · exact transition424 a b raw seedStart
    · exact transition425 a b raw seedStart
    · exact transition426 a b raw seedStart
    · exact transition427 a b raw seedStart
    · exact transition428 a b raw seedStart
    · exact transition429 a b raw seedStart
    · exact transition430 a b raw seedStart
    · exact transition431 a b raw seedStart
    · exact transition432 a b raw seedStart
    · exact transition433 a b raw seedStart
    · exact transition434 a b raw seedStart
    · exact transition435 a b raw seedStart
  · change (state436 a b raw seedStart).observed = some (Task2.dot32 a b)
    exact congrArg some (final_word a b raw seedStart)
  · intro n hn
    interval_cases n <;> rfl
theorem correct : Task2.Implements Task2.Imported.candidate Task2.sourceEval := by
  constructor
  · exact Task2.Imported.CandidateAdapter.initial_exists
  · refine ⟨436, ?_⟩
    intro a b s hs
    refine ⟨436, Task2.dot32 a b, le_rfl, ?_, Task2.source_agrees a b⟩
    have hp := initial_parameterization a b s hs
    rw [hp]
    exact first_result a b s.raw s.start
#print axioms first_result
#print axioms correct
end Task2.Imported.CandidateTrace
