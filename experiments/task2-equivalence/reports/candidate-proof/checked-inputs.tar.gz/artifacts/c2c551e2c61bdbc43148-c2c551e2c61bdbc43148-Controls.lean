import Task2.Imported.CandidateAdapter

def main (args : List String) : IO Unit :=
  Task2.Trace.runControls Task2.Imported.CandidateAdapter.harness args
