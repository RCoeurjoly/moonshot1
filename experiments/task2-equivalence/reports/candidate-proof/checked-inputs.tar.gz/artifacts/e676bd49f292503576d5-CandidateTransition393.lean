import Task2.Imported.CandidateCuts1
import Task2.Imported.CandidateCuts2
import Task2.Imported.CandidateCuts4
import Task2.Imported.CandidateCuts5
import Task2.Imported.CandidateCuts7
import Task2.Imported.CandidateCuts8
import Task2.Imported.CandidateCuts41
import Task2.Imported.CandidateCuts42
import Task2.Imported.CandidateCuts43
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.CandidateTrace
theorem transition393 (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) :
    Task2.Imported.CandidateAdapter.step (state393 a b raw seedStart) = state394 a b raw seedStart := by
  have h0 : Task2.Imported.CandidateCore.c2lChunk0 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw  = chunk33_0 a b raw seedStart := by
    kernel_exact cut33_0 a b raw seedStart
  have h1 : Task2.Imported.CandidateCore.c2lChunk1 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) = chunk386_1 a b raw seedStart := by
    kernel_exact cut386_1 a b raw seedStart
  have h2 : Task2.Imported.CandidateCore.c2lChunk2 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) = chunk388_2 a b raw seedStart := by
    kernel_exact cut388_2 a b raw seedStart
  have h3 : Task2.Imported.CandidateCore.c2lChunk3 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) = chunk386_3 a b raw seedStart := by
    kernel_exact cut386_3 a b raw seedStart
  have h4 : Task2.Imported.CandidateCore.c2lChunk4 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) = chunk387_4 a b raw seedStart := by
    kernel_exact cut387_4 a b raw seedStart
  have h5 : Task2.Imported.CandidateCore.c2lChunk5 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) = chunk393_5 a b raw seedStart := by
    kernel_exact cut393_5 a b raw seedStart
  have h6 : Task2.Imported.CandidateCore.c2lChunk6 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk393_5 a b raw seedStart) = chunk382_6 a b raw seedStart := by
    kernel_exact cut382_6 a b raw seedStart
  have h7 : Task2.Imported.CandidateCore.c2lChunk7 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) = chunk387_7 a b raw seedStart := by
    kernel_exact cut388_7 a b raw seedStart
  have h8 : Task2.Imported.CandidateCore.c2lChunk8 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk387_7 a b raw seedStart) = chunk383_8 a b raw seedStart := by
    kernel_exact cut383_8 a b raw seedStart
  have h9 : Task2.Imported.CandidateCore.c2lChunk9 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk383_8 a b raw seedStart) = chunk11_9 a b raw seedStart := by
    kernel_exact cut11_9 a b raw seedStart
  have h10 : Task2.Imported.CandidateCore.c2lChunk10 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk383_8 a b raw seedStart) (chunk11_9 a b raw seedStart) = chunk380_10 a b raw seedStart := by
    kernel_exact cut384_10 a b raw seedStart
  have h11 : Task2.Imported.CandidateCore.c2lChunk11 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk383_8 a b raw seedStart) (chunk380_10 a b raw seedStart) = chunk393_11 a b raw seedStart := by
    kernel_exact cut393_11 a b raw seedStart
  have h12 : Task2.Imported.CandidateCore.c2lChunk12 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk393_11 a b raw seedStart) = chunk393_12 a b raw seedStart := by
    kernel_exact cut393_12 a b raw seedStart
  have h13 : Task2.Imported.CandidateCore.c2lChunk13 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk380_10 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk393_12 a b raw seedStart) = chunk393_13 a b raw seedStart := by
    kernel_exact cut393_13 a b raw seedStart
  have h14 : Task2.Imported.CandidateCore.c2lChunk14 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk383_8 a b raw seedStart) (chunk380_10 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk393_13 a b raw seedStart) = chunk393_14 a b raw seedStart := by
    kernel_exact cut393_14 a b raw seedStart
  have h15 : Task2.Imported.CandidateCore.c2lChunk15 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk393_14 a b raw seedStart) = chunk393_15 a b raw seedStart := by
    kernel_exact cut393_15 a b raw seedStart
  have h16 : Task2.Imported.CandidateCore.c2lChunk16 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk380_10 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk393_13 a b raw seedStart) (chunk393_15 a b raw seedStart) = chunk21_16 a b raw seedStart := by
    kernel_exact cut43_16 a b raw seedStart
  have h17 : Task2.Imported.CandidateCore.c2lChunk17 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk380_10 a b raw seedStart) (chunk393_13 a b raw seedStart) (chunk21_16 a b raw seedStart) = chunk385_17 a b raw seedStart := by
    kernel_exact cut385_17 a b raw seedStart
  have h18 : Task2.Imported.CandidateCore.c2lChunk18 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk380_10 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk393_13 a b raw seedStart) (chunk393_14 a b raw seedStart) (chunk393_15 a b raw seedStart) (chunk385_17 a b raw seedStart) = chunk392_18 a b raw seedStart := by
    kernel_exact cut393_18 a b raw seedStart
  have h19 : Task2.Imported.CandidateCore.c2lChunk19 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk393_15 a b raw seedStart) (chunk21_16 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk392_18 a b raw seedStart) = chunk393_19 a b raw seedStart := by
    kernel_exact cut393_19 a b raw seedStart
  have h20 : Task2.Imported.CandidateCore.c2lChunk20 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk21_16 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk393_19 a b raw seedStart) = chunk43_20 a b raw seedStart := by
    kernel_exact cut43_20 a b raw seedStart
  have h21 : Task2.Imported.CandidateCore.c2lChunk21 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_13 a b raw seedStart) (chunk21_16 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) = chunk384_21 a b raw seedStart := by
    kernel_exact cut385_21 a b raw seedStart
  have h22 : Task2.Imported.CandidateCore.c2lChunk22 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk393_15 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) = chunk19_22 a b raw seedStart := by
    kernel_exact cut19_22 a b raw seedStart
  have h23 : Task2.Imported.CandidateCore.c2lChunk23 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk393_14 a b raw seedStart) (chunk393_15 a b raw seedStart) (chunk21_16 a b raw seedStart) (chunk392_18 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk19_22 a b raw seedStart) = chunk393_23 a b raw seedStart := by
    kernel_exact cut393_23 a b raw seedStart
  have h24 : Task2.Imported.CandidateCore.c2lChunk24 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk393_15 a b raw seedStart) (chunk21_16 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk393_23 a b raw seedStart) = chunk21_24 a b raw seedStart := by
    kernel_exact cut22_24 a b raw seedStart
  have h25 : Task2.Imported.CandidateCore.c2lChunk25 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk21_24 a b raw seedStart) = chunk15_25 a b raw seedStart := by
    kernel_exact cut18_25 a b raw seedStart
  have h26 : Task2.Imported.CandidateCore.c2lChunk26 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk21_16 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk19_22 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk15_25 a b raw seedStart) = chunk388_26 a b raw seedStart := by
    kernel_exact cut389_26 a b raw seedStart
  have h27 : Task2.Imported.CandidateCore.c2lChunk27 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk19_22 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk388_26 a b raw seedStart) = chunk20_27 a b raw seedStart := by
    kernel_exact cut41_27 a b raw seedStart
  have h28 : Task2.Imported.CandidateCore.c2lChunk28 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk392_18 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk19_22 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk20_27 a b raw seedStart) = chunk387_28 a b raw seedStart := by
    kernel_exact cut388_28 a b raw seedStart
  have h29 : Task2.Imported.CandidateCore.c2lChunk29 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk393_11 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk19_22 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk387_28 a b raw seedStart) = chunk16_29 a b raw seedStart := by
    kernel_exact cut16_29 a b raw seedStart
  have h30 : Task2.Imported.CandidateCore.c2lChunk30 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk21_16 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk388_26 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk16_29 a b raw seedStart) = chunk384_30 a b raw seedStart := by
    kernel_exact cut385_30 a b raw seedStart
  have h31 : Task2.Imported.CandidateCore.c2lChunk31 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk387_28 a b raw seedStart) (chunk16_29 a b raw seedStart) (chunk384_30 a b raw seedStart) = chunk389_31 a b raw seedStart := by
    kernel_exact cut389_31 a b raw seedStart
  have h32 : Task2.Imported.CandidateCore.c2lChunk32 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk21_16 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk16_29 a b raw seedStart) (chunk384_30 a b raw seedStart) (chunk389_31 a b raw seedStart) = chunk1_32 a b raw seedStart := by
    kernel_exact cut4_32 a b raw seedStart
  have h33 : Task2.Imported.CandidateCore.c2lChunk33 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk393_5 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk384_30 a b raw seedStart) (chunk389_31 a b raw seedStart) (chunk1_32 a b raw seedStart) = chunk385_33 a b raw seedStart := by
    kernel_exact cut385_33 a b raw seedStart
  have h34 : Task2.Imported.CandidateCore.c2lChunk34 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk393_23 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk384_30 a b raw seedStart) (chunk389_31 a b raw seedStart) (chunk1_32 a b raw seedStart) (chunk385_33 a b raw seedStart) = chunk389_34 a b raw seedStart := by
    kernel_exact cut390_34 a b raw seedStart
  have h35 : Task2.Imported.CandidateCore.c2lChunk35 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_19 a b raw seedStart) (chunk43_20 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk21_24 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk384_30 a b raw seedStart) (chunk385_33 a b raw seedStart) (chunk389_34 a b raw seedStart) = chunk390_35 a b raw seedStart := by
    kernel_exact cut390_35 a b raw seedStart
  have h36 : Task2.Imported.CandidateCore.c2lChunk36 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk384_21 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk384_30 a b raw seedStart) (chunk1_32 a b raw seedStart) (chunk385_33 a b raw seedStart) (chunk390_35 a b raw seedStart) = chunk389_36 a b raw seedStart := by
    kernel_exact cut390_36 a b raw seedStart
  have h37 : Task2.Imported.CandidateCore.c2lChunk37 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk393_12 a b raw seedStart) (chunk20_27 a b raw seedStart) (chunk390_35 a b raw seedStart) (chunk389_36 a b raw seedStart) = chunk391_37 a b raw seedStart := by
    kernel_exact cut391_37 a b raw seedStart
  have h38 : Task2.Imported.CandidateCore.c2lChunk38 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk390_35 a b raw seedStart) (chunk389_36 a b raw seedStart) (chunk391_37 a b raw seedStart) = chunk392_38 a b raw seedStart := by
    kernel_exact cut392_38 a b raw seedStart
  have h39 : Task2.Imported.CandidateCore.c2lChunk39 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk390_35 a b raw seedStart) (chunk389_36 a b raw seedStart) (chunk391_37 a b raw seedStart) (chunk392_38 a b raw seedStart) = chunk393_39 a b raw seedStart := by
    kernel_exact cut393_39 a b raw seedStart
  have h40 : Task2.Imported.CandidateCore.c2lChunk40 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk390_35 a b raw seedStart) (chunk389_36 a b raw seedStart) (chunk391_37 a b raw seedStart) (chunk392_38 a b raw seedStart) (chunk393_39 a b raw seedStart) = chunk392_40 a b raw seedStart := by
    kernel_exact cut392_40 a b raw seedStart
  have h41 : Task2.Imported.CandidateCore.c2lChunk41 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk392_38 a b raw seedStart) (chunk393_39 a b raw seedStart) (chunk392_40 a b raw seedStart) = chunk393_41 a b raw seedStart := by
    kernel_exact cut393_41 a b raw seedStart
  have h42 : Task2.Imported.CandidateCore.c2lChunk42 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk392_38 a b raw seedStart) (chunk392_40 a b raw seedStart) (chunk393_41 a b raw seedStart) = chunk372_42 a b raw seedStart := by
    kernel_exact cut372_42 a b raw seedStart
  have h43 : Task2.Imported.CandidateCore.c2lChunk43 (Task2.Imported.CandidateAdapter.inputs (state393 a b raw seedStart)) (state393 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk392_38 a b raw seedStart) (chunk393_41 a b raw seedStart) (chunk372_42 a b raw seedStart) = chunk371_43 a b raw seedStart := by
    kernel_exact cut372_43 a b raw seedStart
  simp only [Task2.Imported.CandidateAdapter.step, Task2.Imported.CandidateCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43]
  kernel_rfl
#print axioms transition393
end Task2.Imported.CandidateTrace
