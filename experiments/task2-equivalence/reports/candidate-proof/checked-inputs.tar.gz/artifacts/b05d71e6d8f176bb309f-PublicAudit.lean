import Task2.Candidate
namespace Task2.PublicAudit
theorem claim_type_check : Task2.Implements Task2.Imported.candidate Task2.sourceEval :=
  Task2.candidate_correct
end Task2.PublicAudit
#check Task2.candidate_correct
#print axioms Task2.candidate_correct
#print axioms Task2.PublicAudit.claim_type_check
