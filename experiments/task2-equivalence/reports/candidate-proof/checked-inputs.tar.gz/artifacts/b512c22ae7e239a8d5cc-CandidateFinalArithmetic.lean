import Task2.Imported.CandidateTrace
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.CandidateTrace
theorem final_word (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) : (v3212 a b raw seedStart) = Task2.dot32 a b := by
  simp [v3102, v3103, v3107, v3112, v3113, v3114, v3115, v3118, v3119, v3120, v3122, v3125, v3126, v3127, v3129, v3132, v3133, v3134, v3136, v3139, v3140, v3141, v3143, v3146, v3147, v3148, v3150, v3153, v3154, v3155, v3157, v3160, v3161, v3162, v3164, v3167, v3168, v3169, v3171, v3174, v3175, v3176, v3178, v3181, v3182, v3183, v3185, v3188, v3189, v3190, v3192, v3195, v3196, v3197, v3199, v3202, v3203, v3204, v3206, v3208, v3209, v3210, v3212, Task2.dot32, List.finRange, List.ofFn, Fin.foldr, Fin.foldr.loop, BitVec.mul_comm]
#print axioms final_word
end Task2.Imported.CandidateTrace
