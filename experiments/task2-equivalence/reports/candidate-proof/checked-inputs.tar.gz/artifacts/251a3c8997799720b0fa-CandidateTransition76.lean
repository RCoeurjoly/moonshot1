import Task2.Imported.CandidateCuts1
import Task2.Imported.CandidateCuts2
import Task2.Imported.CandidateCuts3
import Task2.Imported.CandidateCuts5
import Task2.Imported.CandidateCuts9
import Task2.Imported.CandidateCuts10
import Task2.Imported.CandidateCuts11
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.CandidateTrace
theorem transition76 (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) :
    Task2.Imported.CandidateAdapter.step (state76 a b raw seedStart) = state77 a b raw seedStart := by
  have h0 : Task2.Imported.CandidateCore.c2lChunk0 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw  = chunk24_0 a b raw seedStart := by
    kernel_exact cut24_0 a b raw seedStart
  have h1 : Task2.Imported.CandidateCore.c2lChunk1 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) = chunk26_1 a b raw seedStart := by
    kernel_exact cut26_1 a b raw seedStart
  have h2 : Task2.Imported.CandidateCore.c2lChunk2 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) = chunk75_2 a b raw seedStart := by
    kernel_exact cut75_2 a b raw seedStart
  have h3 : Task2.Imported.CandidateCore.c2lChunk3 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_2 a b raw seedStart) = chunk61_3 a b raw seedStart := by
    kernel_exact cut61_3 a b raw seedStart
  have h4 : Task2.Imported.CandidateCore.c2lChunk4 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) = chunk62_4 a b raw seedStart := by
    kernel_exact cut62_4 a b raw seedStart
  have h5 : Task2.Imported.CandidateCore.c2lChunk5 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk62_4 a b raw seedStart) = chunk75_5 a b raw seedStart := by
    kernel_exact cut75_5 a b raw seedStart
  have h6 : Task2.Imported.CandidateCore.c2lChunk6 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk62_4 a b raw seedStart) (chunk75_5 a b raw seedStart) = chunk57_6 a b raw seedStart := by
    kernel_exact cut57_6 a b raw seedStart
  have h7 : Task2.Imported.CandidateCore.c2lChunk7 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk62_4 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) = chunk62_7 a b raw seedStart := by
    kernel_exact cut63_7 a b raw seedStart
  have h8 : Task2.Imported.CandidateCore.c2lChunk8 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk62_4 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) (chunk62_7 a b raw seedStart) = chunk58_8 a b raw seedStart := by
    kernel_exact cut58_8 a b raw seedStart
  have h9 : Task2.Imported.CandidateCore.c2lChunk9 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk62_4 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) (chunk62_7 a b raw seedStart) (chunk58_8 a b raw seedStart) = chunk11_9 a b raw seedStart := by
    kernel_exact cut11_9 a b raw seedStart
  have h10 : Task2.Imported.CandidateCore.c2lChunk10 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk62_4 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) (chunk62_7 a b raw seedStart) (chunk58_8 a b raw seedStart) (chunk11_9 a b raw seedStart) = chunk55_10 a b raw seedStart := by
    kernel_exact cut59_10 a b raw seedStart
  have h11 : Task2.Imported.CandidateCore.c2lChunk11 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) (chunk58_8 a b raw seedStart) (chunk55_10 a b raw seedStart) = chunk68_11 a b raw seedStart := by
    kernel_exact cut68_11 a b raw seedStart
  have h12 : Task2.Imported.CandidateCore.c2lChunk12 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk62_4 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) (chunk68_11 a b raw seedStart) = chunk69_12 a b raw seedStart := by
    kernel_exact cut69_12 a b raw seedStart
  have h13 : Task2.Imported.CandidateCore.c2lChunk13 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk62_7 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk55_10 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk69_12 a b raw seedStart) = chunk68_13 a b raw seedStart := by
    kernel_exact cut68_13 a b raw seedStart
  have h14 : Task2.Imported.CandidateCore.c2lChunk14 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) (chunk58_8 a b raw seedStart) (chunk55_10 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk68_13 a b raw seedStart) = chunk72_14 a b raw seedStart := by
    kernel_exact cut73_14 a b raw seedStart
  have h15 : Task2.Imported.CandidateCore.c2lChunk15 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk62_4 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) (chunk62_7 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk72_14 a b raw seedStart) = chunk76_15 a b raw seedStart := by
    kernel_exact cut76_15 a b raw seedStart
  have h16 : Task2.Imported.CandidateCore.c2lChunk16 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk55_10 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk68_13 a b raw seedStart) (chunk76_15 a b raw seedStart) = chunk5_16 a b raw seedStart := by
    kernel_exact cut5_16 a b raw seedStart
  have h17 : Task2.Imported.CandidateCore.c2lChunk17 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk61_3 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk55_10 a b raw seedStart) (chunk68_13 a b raw seedStart) (chunk5_16 a b raw seedStart) = chunk57_17 a b raw seedStart := by
    kernel_exact cut73_17 a b raw seedStart
  have h18 : Task2.Imported.CandidateCore.c2lChunk18 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk57_6 a b raw seedStart) (chunk55_10 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk68_13 a b raw seedStart) (chunk72_14 a b raw seedStart) (chunk76_15 a b raw seedStart) (chunk57_17 a b raw seedStart) = chunk76_18 a b raw seedStart := by
    kernel_exact cut76_18 a b raw seedStart
  have h19 : Task2.Imported.CandidateCore.c2lChunk19 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk76_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk57_17 a b raw seedStart) (chunk76_18 a b raw seedStart) = chunk74_19 a b raw seedStart := by
    kernel_exact cut74_19 a b raw seedStart
  have h20 : Task2.Imported.CandidateCore.c2lChunk20 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk57_17 a b raw seedStart) (chunk74_19 a b raw seedStart) = chunk21_20 a b raw seedStart := by
    kernel_exact cut24_20 a b raw seedStart
  have h21 : Task2.Imported.CandidateCore.c2lChunk21 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk68_13 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk57_17 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) = chunk74_21 a b raw seedStart := by
    kernel_exact cut74_21 a b raw seedStart
  have h22 : Task2.Imported.CandidateCore.c2lChunk22 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk76_15 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) = chunk26_22 a b raw seedStart := by
    kernel_exact cut26_22 a b raw seedStart
  have h23 : Task2.Imported.CandidateCore.c2lChunk23 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk72_14 a b raw seedStart) (chunk76_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk76_18 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk26_22 a b raw seedStart) = chunk76_23 a b raw seedStart := by
    kernel_exact cut76_23 a b raw seedStart
  have h24 : Task2.Imported.CandidateCore.c2lChunk24 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk76_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk76_23 a b raw seedStart) = chunk14_24 a b raw seedStart := by
    kernel_exact cut14_24 a b raw seedStart
  have h25 : Task2.Imported.CandidateCore.c2lChunk25 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk57_17 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_24 a b raw seedStart) = chunk14_25 a b raw seedStart := by
    kernel_exact cut14_25 a b raw seedStart
  have h26 : Task2.Imported.CandidateCore.c2lChunk26 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk57_17 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk26_22 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_25 a b raw seedStart) = chunk76_26 a b raw seedStart := by
    kernel_exact cut76_26 a b raw seedStart
  have h27 : Task2.Imported.CandidateCore.c2lChunk27 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk26_22 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_25 a b raw seedStart) (chunk76_26 a b raw seedStart) = chunk14_27 a b raw seedStart := by
    kernel_exact cut26_27 a b raw seedStart
  have h28 : Task2.Imported.CandidateCore.c2lChunk28 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk76_18 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk26_22 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) = chunk72_28 a b raw seedStart := by
    kernel_exact cut73_28 a b raw seedStart
  have h29 : Task2.Imported.CandidateCore.c2lChunk29 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk68_11 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk26_22 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_25 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk72_28 a b raw seedStart) = chunk26_29 a b raw seedStart := by
    kernel_exact cut26_29 a b raw seedStart
  have h30 : Task2.Imported.CandidateCore.c2lChunk30 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_25 a b raw seedStart) (chunk76_26 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk26_29 a b raw seedStart) = chunk76_30 a b raw seedStart := by
    kernel_exact cut76_30 a b raw seedStart
  have h31 : Task2.Imported.CandidateCore.c2lChunk31 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_25 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk72_28 a b raw seedStart) (chunk26_29 a b raw seedStart) (chunk76_30 a b raw seedStart) = chunk72_31 a b raw seedStart := by
    kernel_exact cut72_31 a b raw seedStart
  have h32 : Task2.Imported.CandidateCore.c2lChunk32 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk26_29 a b raw seedStart) (chunk76_30 a b raw seedStart) (chunk72_31 a b raw seedStart) = chunk25_32 a b raw seedStart := by
    kernel_exact cut26_32 a b raw seedStart
  have h33 : Task2.Imported.CandidateCore.c2lChunk33 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk75_2 a b raw seedStart) (chunk75_5 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk76_30 a b raw seedStart) (chunk72_31 a b raw seedStart) (chunk25_32 a b raw seedStart) = chunk24_33 a b raw seedStart := by
    kernel_exact cut76_33 a b raw seedStart
  have h34 : Task2.Imported.CandidateCore.c2lChunk34 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk76_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk76_30 a b raw seedStart) (chunk72_31 a b raw seedStart) (chunk25_32 a b raw seedStart) (chunk24_33 a b raw seedStart) = chunk72_34 a b raw seedStart := by
    kernel_exact cut76_34 a b raw seedStart
  have h35 : Task2.Imported.CandidateCore.c2lChunk35 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk74_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk76_30 a b raw seedStart) (chunk24_33 a b raw seedStart) (chunk72_34 a b raw seedStart) = chunk76_35 a b raw seedStart := by
    kernel_exact cut76_35 a b raw seedStart
  have h36 : Task2.Imported.CandidateCore.c2lChunk36 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk74_21 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk76_30 a b raw seedStart) (chunk25_32 a b raw seedStart) (chunk24_33 a b raw seedStart) (chunk76_35 a b raw seedStart) = chunk64_36 a b raw seedStart := by
    kernel_exact cut76_36 a b raw seedStart
  have h37 : Task2.Imported.CandidateCore.c2lChunk37 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk69_12 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk76_35 a b raw seedStart) (chunk64_36 a b raw seedStart) = chunk66_37 a b raw seedStart := by
    kernel_exact cut66_37 a b raw seedStart
  have h38 : Task2.Imported.CandidateCore.c2lChunk38 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk76_35 a b raw seedStart) (chunk64_36 a b raw seedStart) (chunk66_37 a b raw seedStart) = chunk67_38 a b raw seedStart := by
    kernel_exact cut67_38 a b raw seedStart
  have h39 : Task2.Imported.CandidateCore.c2lChunk39 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk76_35 a b raw seedStart) (chunk64_36 a b raw seedStart) (chunk66_37 a b raw seedStart) (chunk67_38 a b raw seedStart) = chunk68_39 a b raw seedStart := by
    kernel_exact cut68_39 a b raw seedStart
  have h40 : Task2.Imported.CandidateCore.c2lChunk40 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk76_35 a b raw seedStart) (chunk64_36 a b raw seedStart) (chunk66_37 a b raw seedStart) (chunk67_38 a b raw seedStart) (chunk68_39 a b raw seedStart) = chunk67_40 a b raw seedStart := by
    kernel_exact cut67_40 a b raw seedStart
  have h41 : Task2.Imported.CandidateCore.c2lChunk41 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk67_38 a b raw seedStart) (chunk68_39 a b raw seedStart) (chunk67_40 a b raw seedStart) = chunk70_41 a b raw seedStart := by
    kernel_exact cut70_41 a b raw seedStart
  have h42 : Task2.Imported.CandidateCore.c2lChunk42 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk67_38 a b raw seedStart) (chunk67_40 a b raw seedStart) (chunk70_41 a b raw seedStart) = chunk72_42 a b raw seedStart := by
    kernel_exact cut72_42 a b raw seedStart
  have h43 : Task2.Imported.CandidateCore.c2lChunk43 (Task2.Imported.CandidateAdapter.inputs (state76 a b raw seedStart)) (state76 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk67_38 a b raw seedStart) (chunk70_41 a b raw seedStart) (chunk72_42 a b raw seedStart) = chunk71_43 a b raw seedStart := by
    kernel_exact cut72_43 a b raw seedStart
  simp only [Task2.Imported.CandidateAdapter.step, Task2.Imported.CandidateCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43]
  kernel_rfl
#print axioms transition76
end Task2.Imported.CandidateTrace
