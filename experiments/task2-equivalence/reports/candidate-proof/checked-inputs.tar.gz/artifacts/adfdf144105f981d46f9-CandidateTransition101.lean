import Task2.Imported.CandidateCuts1
import Task2.Imported.CandidateCuts2
import Task2.Imported.CandidateCuts3
import Task2.Imported.CandidateCuts5
import Task2.Imported.CandidateCuts12
import Task2.Imported.CandidateCuts13
import Task2.Imported.CandidateCuts14
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.CandidateTrace
theorem transition101 (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) :
    Task2.Imported.CandidateAdapter.step (state101 a b raw seedStart) = state102 a b raw seedStart := by
  have h0 : Task2.Imported.CandidateCore.c2lChunk0 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw  = chunk24_0 a b raw seedStart := by
    kernel_exact cut24_0 a b raw seedStart
  have h1 : Task2.Imported.CandidateCore.c2lChunk1 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) = chunk26_1 a b raw seedStart := by
    kernel_exact cut26_1 a b raw seedStart
  have h2 : Task2.Imported.CandidateCore.c2lChunk2 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) = chunk100_2 a b raw seedStart := by
    kernel_exact cut100_2 a b raw seedStart
  have h3 : Task2.Imported.CandidateCore.c2lChunk3 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_2 a b raw seedStart) = chunk86_3 a b raw seedStart := by
    kernel_exact cut86_3 a b raw seedStart
  have h4 : Task2.Imported.CandidateCore.c2lChunk4 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) = chunk87_4 a b raw seedStart := by
    kernel_exact cut87_4 a b raw seedStart
  have h5 : Task2.Imported.CandidateCore.c2lChunk5 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk87_4 a b raw seedStart) = chunk100_5 a b raw seedStart := by
    kernel_exact cut100_5 a b raw seedStart
  have h6 : Task2.Imported.CandidateCore.c2lChunk6 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk87_4 a b raw seedStart) (chunk100_5 a b raw seedStart) = chunk82_6 a b raw seedStart := by
    kernel_exact cut82_6 a b raw seedStart
  have h7 : Task2.Imported.CandidateCore.c2lChunk7 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk87_4 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) = chunk87_7 a b raw seedStart := by
    kernel_exact cut88_7 a b raw seedStart
  have h8 : Task2.Imported.CandidateCore.c2lChunk8 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk87_4 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) (chunk87_7 a b raw seedStart) = chunk83_8 a b raw seedStart := by
    kernel_exact cut83_8 a b raw seedStart
  have h9 : Task2.Imported.CandidateCore.c2lChunk9 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk87_4 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) (chunk87_7 a b raw seedStart) (chunk83_8 a b raw seedStart) = chunk11_9 a b raw seedStart := by
    kernel_exact cut11_9 a b raw seedStart
  have h10 : Task2.Imported.CandidateCore.c2lChunk10 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk87_4 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) (chunk87_7 a b raw seedStart) (chunk83_8 a b raw seedStart) (chunk11_9 a b raw seedStart) = chunk80_10 a b raw seedStart := by
    kernel_exact cut84_10 a b raw seedStart
  have h11 : Task2.Imported.CandidateCore.c2lChunk11 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) (chunk83_8 a b raw seedStart) (chunk80_10 a b raw seedStart) = chunk93_11 a b raw seedStart := by
    kernel_exact cut93_11 a b raw seedStart
  have h12 : Task2.Imported.CandidateCore.c2lChunk12 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk87_4 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) (chunk93_11 a b raw seedStart) = chunk94_12 a b raw seedStart := by
    kernel_exact cut94_12 a b raw seedStart
  have h13 : Task2.Imported.CandidateCore.c2lChunk13 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk87_7 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk80_10 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk94_12 a b raw seedStart) = chunk93_13 a b raw seedStart := by
    kernel_exact cut93_13 a b raw seedStart
  have h14 : Task2.Imported.CandidateCore.c2lChunk14 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) (chunk83_8 a b raw seedStart) (chunk80_10 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk93_13 a b raw seedStart) = chunk97_14 a b raw seedStart := by
    kernel_exact cut98_14 a b raw seedStart
  have h15 : Task2.Imported.CandidateCore.c2lChunk15 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk87_4 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) (chunk87_7 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk97_14 a b raw seedStart) = chunk101_15 a b raw seedStart := by
    kernel_exact cut101_15 a b raw seedStart
  have h16 : Task2.Imported.CandidateCore.c2lChunk16 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk80_10 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk93_13 a b raw seedStart) (chunk101_15 a b raw seedStart) = chunk5_16 a b raw seedStart := by
    kernel_exact cut5_16 a b raw seedStart
  have h17 : Task2.Imported.CandidateCore.c2lChunk17 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk86_3 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk80_10 a b raw seedStart) (chunk93_13 a b raw seedStart) (chunk5_16 a b raw seedStart) = chunk82_17 a b raw seedStart := by
    kernel_exact cut98_17 a b raw seedStart
  have h18 : Task2.Imported.CandidateCore.c2lChunk18 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk82_6 a b raw seedStart) (chunk80_10 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk93_13 a b raw seedStart) (chunk97_14 a b raw seedStart) (chunk101_15 a b raw seedStart) (chunk82_17 a b raw seedStart) = chunk101_18 a b raw seedStart := by
    kernel_exact cut101_18 a b raw seedStart
  have h19 : Task2.Imported.CandidateCore.c2lChunk19 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk101_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk82_17 a b raw seedStart) (chunk101_18 a b raw seedStart) = chunk99_19 a b raw seedStart := by
    kernel_exact cut99_19 a b raw seedStart
  have h20 : Task2.Imported.CandidateCore.c2lChunk20 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk82_17 a b raw seedStart) (chunk99_19 a b raw seedStart) = chunk21_20 a b raw seedStart := by
    kernel_exact cut24_20 a b raw seedStart
  have h21 : Task2.Imported.CandidateCore.c2lChunk21 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk93_13 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk82_17 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) = chunk99_21 a b raw seedStart := by
    kernel_exact cut99_21 a b raw seedStart
  have h22 : Task2.Imported.CandidateCore.c2lChunk22 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk101_15 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) = chunk26_22 a b raw seedStart := by
    kernel_exact cut26_22 a b raw seedStart
  have h23 : Task2.Imported.CandidateCore.c2lChunk23 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk97_14 a b raw seedStart) (chunk101_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk101_18 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk26_22 a b raw seedStart) = chunk101_23 a b raw seedStart := by
    kernel_exact cut101_23 a b raw seedStart
  have h24 : Task2.Imported.CandidateCore.c2lChunk24 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk101_15 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk101_23 a b raw seedStart) = chunk14_24 a b raw seedStart := by
    kernel_exact cut14_24 a b raw seedStart
  have h25 : Task2.Imported.CandidateCore.c2lChunk25 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk82_17 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_24 a b raw seedStart) = chunk14_25 a b raw seedStart := by
    kernel_exact cut14_25 a b raw seedStart
  have h26 : Task2.Imported.CandidateCore.c2lChunk26 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk82_17 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk26_22 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_25 a b raw seedStart) = chunk101_26 a b raw seedStart := by
    kernel_exact cut101_26 a b raw seedStart
  have h27 : Task2.Imported.CandidateCore.c2lChunk27 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk26_22 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_25 a b raw seedStart) (chunk101_26 a b raw seedStart) = chunk14_27 a b raw seedStart := by
    kernel_exact cut26_27 a b raw seedStart
  have h28 : Task2.Imported.CandidateCore.c2lChunk28 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk101_18 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk26_22 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) = chunk97_28 a b raw seedStart := by
    kernel_exact cut98_28 a b raw seedStart
  have h29 : Task2.Imported.CandidateCore.c2lChunk29 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk93_11 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk26_22 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_25 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk97_28 a b raw seedStart) = chunk26_29 a b raw seedStart := by
    kernel_exact cut26_29 a b raw seedStart
  have h30 : Task2.Imported.CandidateCore.c2lChunk30 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_25 a b raw seedStart) (chunk101_26 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk26_29 a b raw seedStart) = chunk101_30 a b raw seedStart := by
    kernel_exact cut101_30 a b raw seedStart
  have h31 : Task2.Imported.CandidateCore.c2lChunk31 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_25 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk97_28 a b raw seedStart) (chunk26_29 a b raw seedStart) (chunk101_30 a b raw seedStart) = chunk97_31 a b raw seedStart := by
    kernel_exact cut97_31 a b raw seedStart
  have h32 : Task2.Imported.CandidateCore.c2lChunk32 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk5_16 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk26_29 a b raw seedStart) (chunk101_30 a b raw seedStart) (chunk97_31 a b raw seedStart) = chunk25_32 a b raw seedStart := by
    kernel_exact cut26_32 a b raw seedStart
  have h33 : Task2.Imported.CandidateCore.c2lChunk33 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk100_2 a b raw seedStart) (chunk100_5 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk101_30 a b raw seedStart) (chunk97_31 a b raw seedStart) (chunk25_32 a b raw seedStart) = chunk24_33 a b raw seedStart := by
    kernel_exact cut101_33 a b raw seedStart
  have h34 : Task2.Imported.CandidateCore.c2lChunk34 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk101_23 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk101_30 a b raw seedStart) (chunk97_31 a b raw seedStart) (chunk25_32 a b raw seedStart) (chunk24_33 a b raw seedStart) = chunk97_34 a b raw seedStart := by
    kernel_exact cut101_34 a b raw seedStart
  have h35 : Task2.Imported.CandidateCore.c2lChunk35 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk99_19 a b raw seedStart) (chunk21_20 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk14_24 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk101_30 a b raw seedStart) (chunk24_33 a b raw seedStart) (chunk97_34 a b raw seedStart) = chunk101_35 a b raw seedStart := by
    kernel_exact cut101_35 a b raw seedStart
  have h36 : Task2.Imported.CandidateCore.c2lChunk36 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk26_1 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk99_21 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk101_30 a b raw seedStart) (chunk25_32 a b raw seedStart) (chunk24_33 a b raw seedStart) (chunk101_35 a b raw seedStart) = chunk89_36 a b raw seedStart := by
    kernel_exact cut101_36 a b raw seedStart
  have h37 : Task2.Imported.CandidateCore.c2lChunk37 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk94_12 a b raw seedStart) (chunk14_27 a b raw seedStart) (chunk101_35 a b raw seedStart) (chunk89_36 a b raw seedStart) = chunk91_37 a b raw seedStart := by
    kernel_exact cut91_37 a b raw seedStart
  have h38 : Task2.Imported.CandidateCore.c2lChunk38 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk101_35 a b raw seedStart) (chunk89_36 a b raw seedStart) (chunk91_37 a b raw seedStart) = chunk92_38 a b raw seedStart := by
    kernel_exact cut92_38 a b raw seedStart
  have h39 : Task2.Imported.CandidateCore.c2lChunk39 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk101_35 a b raw seedStart) (chunk89_36 a b raw seedStart) (chunk91_37 a b raw seedStart) (chunk92_38 a b raw seedStart) = chunk93_39 a b raw seedStart := by
    kernel_exact cut93_39 a b raw seedStart
  have h40 : Task2.Imported.CandidateCore.c2lChunk40 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk101_35 a b raw seedStart) (chunk89_36 a b raw seedStart) (chunk91_37 a b raw seedStart) (chunk92_38 a b raw seedStart) (chunk93_39 a b raw seedStart) = chunk92_40 a b raw seedStart := by
    kernel_exact cut92_40 a b raw seedStart
  have h41 : Task2.Imported.CandidateCore.c2lChunk41 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk92_38 a b raw seedStart) (chunk93_39 a b raw seedStart) (chunk92_40 a b raw seedStart) = chunk95_41 a b raw seedStart := by
    kernel_exact cut95_41 a b raw seedStart
  have h42 : Task2.Imported.CandidateCore.c2lChunk42 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk92_38 a b raw seedStart) (chunk92_40 a b raw seedStart) (chunk95_41 a b raw seedStart) = chunk97_42 a b raw seedStart := by
    kernel_exact cut97_42 a b raw seedStart
  have h43 : Task2.Imported.CandidateCore.c2lChunk43 (Task2.Imported.CandidateAdapter.inputs (state101 a b raw seedStart)) (state101 a b raw seedStart).raw (chunk24_0 a b raw seedStart) (chunk92_38 a b raw seedStart) (chunk95_41 a b raw seedStart) (chunk97_42 a b raw seedStart) = chunk96_43 a b raw seedStart := by
    kernel_exact cut97_43 a b raw seedStart
  simp only [Task2.Imported.CandidateAdapter.step, Task2.Imported.CandidateCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43]
  kernel_rfl
#print axioms transition101
end Task2.Imported.CandidateTrace
