import Task2.Imported.CandidateCore
import Task2.Trace
set_option maxRecDepth 65536
set_option maxHeartbeats 0
namespace Task2.Imported.CandidateAdapter
open Task2
structure State where
  raw : Task2.Imported.CandidateCore.State
  cycles : Nat
  start : Bool
  observed : Option Word

def inputs (s : State) : Task2.Imported.CandidateCore.Inputs := { i0 := (if s.cycles < 4 then 1 else 0), i1 := (0), i2 := (if s.start then 1 else 0), i3 := (1), i4 := (1), i5 := (1) }

def step (s : State) : State :=
  let r := Task2.Imported.CandidateCore.evaluate (inputs s) s.raw
  { raw := r.nextState, cycles := s.cycles + 1,
    start := if s.cycles < 4 then true else if r.outputs.o1 != 0 then false else s.start,
    observed := if s.cycles < 4 then none else if r.outputs.o4 == 1 then some r.outputs.o3 else none }

def initial (a b : Words) (s : State) : Prop :=
  s.cycles = 0 ∧ s.observed = none ∧
  Task2.Imported.CandidateCore.initialValid s.raw = true ∧
  s.raw.g0.s30 = (fun address => a ⟨address.toNat, address.isLt⟩) ∧
  s.raw.g0.s31 = (fun address => b ⟨address.toNat, address.isLt⟩)

def witness (a b : Words) : State :=
  { raw := { g0 := { s0 := (0#1), s1 := (0#1), s2 := (0#64), s3 := (0#64), s4 := (0#1), s5 := (0#1), s6 := (0#64), s7 := (0#64), s8 := (0#64), s9 := (0#64), s10 := (0#64), s11 := (0#64), s12 := (0#64), s13 := (0#64), s14 := (0#64), s15 := (0#64), s16 := (0#64), s17 := (0#64), s18 := (0#64), s19 := (0#64), s20 := (0#64), s21 := (0#64), s22 := (0#64), s23 := (0#64), s24 := (0#64), s25 := (0#64), s26 := (0#64), s27 := (0#64), s28 := (0#1), s29 := (0#1), s30 := (fun address => a ⟨address.toNat, address.isLt⟩), s31 := (fun address => b ⟨address.toNat, address.isLt⟩), s32 := (0#64), s33 := (0#64), s34 := (0#64), s35 := (0#64), s36 := (0#1), s37 := (0#1), s38 := (0#64), s39 := (0#64), s40 := (0#1), s41 := (0#1), s42 := (0#1), s43 := (0#1), s44 := (0#32), s45 := (0#32), s46 := (0#1), s47 := (0#1), s48 := (0#32), s49 := (0#32), s50 := (0#1), s51 := (0#64), s52 := (0#64), s53 := (0#64), s54 := (0#64), s55 := (0#64), s56 := (0#64), s57 := (0#1), s58 := (0#1), s59 := (0#1), s60 := (0#1), s61 := (0#1), s62 := (0#1), s63 := (0#1), s64 := (0#1), s65 := (0#1), s66 := (0#32), s67 := (0#32), s68 := (0#1), s69 := (0#1), s70 := (0#32), s71 := (0#32), s72 := (0#1), s73 := (0#1), s74 := (0#1), s75 := (0#1), s76 := (0#1), s77 := (0#1), s78 := (0#1), s79 := (0#1), s80 := (0#1), s81 := (0#1), s82 := (0#1), s83 := (0#1), s84 := (0#1), s85 := (0#1), s86 := (0#1), s87 := (0#64), s88 := (0#64), s89 := (0#1), s90 := (0#64), s91 := (0#64), s92 := (0#1), s93 := (0#1), s94 := (0#1), s95 := (0#1), s96 := (0#1), s97 := (0#1), s98 := (0#1), s99 := (0#1), s100 := (0#1), s101 := (0#32), s102 := (0#32), s103 := (0#1), s104 := (0#1), s105 := (0#32), s106 := (0#32), s107 := (0#1), s108 := (0#1), s109 := (0#1), s110 := (0#1), s111 := (0#1), s112 := (0#1), s113 := (0#32), s114 := (0#32), s115 := (0#1), s116 := (0#1), s117 := (0#1), s118 := (0#1), s119 := (0#1), s120 := (0#1), s121 := (0#64), s122 := (0#64), s123 := (0#1), s124 := (0#64), s125 := (0#64), s126 := (0#1), s127 := (0#1) }, g1 := { s128 := (0#1), s129 := (0#1), s130 := (0#1), s131 := (0#1), s132 := (0#1), s133 := (0#32), s134 := (0#32), s135 := (0#1), s136 := (0#32), s137 := (0#32), s138 := (0#1), s139 := (0#1), s140 := (0#1), s141 := (0#1), s142 := (0#1), s143 := (0#1), s144 := (0#1), s145 := (0#1), s146 := (0#1), s147 := (0#32), s148 := (0#32), s149 := (0#1), s150 := (0#1), s151 := (0#1), s152 := (0#1), s153 := (0#1), s154 := (0#1), s155 := (0#1), s156 := (0#1), s157 := (0#1), s158 := (0#1), s159 := (0#1), s160 := (0#1), s161 := (0#1), s162 := (0#1), s163 := (0#64), s164 := (0#64), s165 := (0#1), s166 := (0#64), s167 := (0#64), s168 := (0#1), s169 := (0#1), s170 := (0#1), s171 := (0#1), s172 := (0#1), s173 := (0#1), s174 := (0#1), s175 := (0#1), s176 := (0#1), s177 := (0#1), s178 := (0#1), s179 := (0#1), s180 := (0#1), s181 := (0#1), s182 := (0#32), s183 := (0#32), s184 := (0#1), s185 := (0#1), s186 := (0#32), s187 := (0#32), s188 := (0#1), s189 := (0#1), s190 := (0#1), s191 := (0#1), s192 := (0#1), s193 := (0#1), s194 := (0#1), s195 := (0#1), s196 := (0#1), s197 := (0#1), s198 := (0#1), s199 := (0#1), s200 := (0#64), s201 := (0#64), s202 := (0#1), s203 := (0#64), s204 := (0#64), s205 := (0#1), s206 := (0#1), s207 := (0#1), s208 := (0#1), s209 := (0#1), s210 := (0#1), s211 := (0#1), s212 := (0#1), s213 := (0#1), s214 := (0#1), s215 := (0#1), s216 := (0#1), s217 := (0#1), s218 := (0#1), s219 := (0#1), s220 := (0#1), s221 := (0#32), s222 := (0#32), s223 := (0#1), s224 := (0#32), s225 := (0#32), s226 := (0#1), s227 := (0#1), s228 := (0#1), s229 := (0#1), s230 := (0#1), s231 := (0#1), s232 := (0#1), s233 := (0#1), s234 := (0#1), s235 := (0#1), s236 := (0#1), s237 := (0#1), s238 := (0#1), s239 := (0#1), s240 := (0#1), s241 := (0#1), s242 := (0#1), s243 := (0#1), s244 := (0#1), s245 := (0#1), s246 := (0#1), s247 := (0#1), s248 := (0#1), s249 := (0#1), s250 := (0#64), s251 := (0#64), s252 := (0#1), s253 := (0#64), s254 := (0#64), s255 := (0#1) }, g2 := { s256 := (0#1), s257 := (0#1), s258 := (0#1), s259 := (0#1), s260 := (0#1), s261 := (0#1), s262 := (0#1), s263 := (0#1), s264 := (0#1), s265 := (0#1), s266 := (0#1), s267 := (0#1), s268 := (0#1), s269 := (0#1), s270 := (0#1), s271 := (0#1), s272 := (0#1), s273 := (0#32), s274 := (0#32), s275 := (0#1), s276 := (0#1), s277 := (0#1), s278 := (0#1), s279 := (0#1), s280 := (0#1), s281 := (0#1), s282 := (0#1), s283 := (0#1), s284 := (0#1), s285 := (0#1), s286 := (0#1), s287 := (0#1), s288 := (0#1), s289 := (0#1), s290 := (0#1), s291 := (0#1), s292 := (0#1), s293 := (0#1), s294 := (0#1), s295 := (0#64), s296 := (0#64), s297 := (0#1), s298 := (0#64), s299 := (0#64), s300 := (0#1), s301 := (0#1), s302 := (0#1), s303 := (0#1), s304 := (0#1), s305 := (0#1), s306 := (0#1), s307 := (0#1), s308 := (0#1), s309 := (0#1), s310 := (0#1), s311 := (0#1), s312 := (0#1), s313 := (0#32), s314 := (0#32), s315 := (0#1), s316 := (0#1), s317 := (0#1), s318 := (0#1), s319 := (0#1), s320 := (0#1), s321 := (0#1), s322 := (0#1), s323 := (0#1), s324 := (0#1), s325 := (0#1), s326 := (0#1), s327 := (0#1), s328 := (0#1), s329 := (0#1), s330 := (0#1), s331 := (0#1), s332 := (0#1), s333 := (0#1), s334 := (0#1), s335 := (0#1), s336 := (0#1), s337 := (0#1), s338 := (0#1), s339 := (0#1), s340 := (0#1), s341 := (0#1), s342 := (0#32), s343 := (0#32), s344 := (0#1), s345 := (0#1), s346 := (0#1), s347 := (0#1), s348 := (0#1), s349 := (0#1), s350 := (0#1), s351 := (0#1), s352 := (0#1), s353 := (0#1), s354 := (0#1), s355 := (0#1), s356 := (0#1), s357 := (0#1), s358 := (0#1), s359 := (0#1), s360 := (0#1), s361 := (0#1), s362 := (0#1), s363 := (0#32), s364 := (0#32), s365 := (0#1), s366 := (0#1), s367 := (0#1), s368 := (0#1), s369 := (0#1), s370 := (0#32), s371 := (0#1), s372 := (0#1), s373 := (0#1), s374 := (0#1), s375 := (0#1), s376 := (0#1), s377 := (0#32), s378 := (0#32), s379 := (0#1), s380 := (0#1), s381 := (0#1), s382 := (0#1), s383 := (0#1) }, g3 := { s384 := (0#1), s385 := (0#1), s386 := (0#1), s387 := (0#1), s388 := (0#1), s389 := (0#1), s390 := (0#32), s391 := (0#32), s392 := (0#1), s393 := (0#1), s394 := (0#1), s395 := (0#1), s396 := (0#1), s397 := (0#1), s398 := (0#1), s399 := (0#1), s400 := (0#1), s401 := (0#1), s402 := (0#32), s403 := (0#32), s404 := (0#1), s405 := (0#1), s406 := (0#1), s407 := (0#1), s408 := (0#1), s409 := (0#1), s410 := (0#1), s411 := (0#1), s412 := (0#1), s413 := (0#1), s414 := (0#1), s415 := (0#1), s416 := (0#1), s417 := (0#1), s418 := (0#1), s419 := (0#32), s420 := (0#32), s421 := (0#1), s422 := (0#1), s423 := (0#1), s424 := (0#1), s425 := (0#1), s426 := (0#1), s427 := (0#32), s428 := (0#32), s429 := (0#1), s430 := (0#1), s431 := (0#1), s432 := (0#1), s433 := (0#1), s434 := (0#1), s435 := (0#1), s436 := (0#1), s437 := (0#1), s438 := (0#1), s439 := (0#32), s440 := (0#32) } },
    cycles := 0, start := false, observed := none }

theorem initial_exists (a b : Words) : ∃ s, initial a b s := by
  exact ⟨witness a b, rfl, rfl, rfl, rfl, rfl⟩

def advance (s : State) : Nat → State
  | 0 => s
  | n + 1 => step (advance s n)

theorem memoryA_step (s : State) : (step s).raw.g0.s30 = s.raw.g0.s30 := by rfl

theorem memoryA_preserved (s : State) (n : Nat) :
    (advance s n).raw.g0.s30 = s.raw.g0.s30 := by
  induction n with
  | zero => rfl
  | succ n ih => exact Eq.trans (memoryA_step (advance s n)) ih

theorem memoryB_step (s : State) : (step s).raw.g0.s31 = s.raw.g0.s31 := by rfl

theorem memoryB_preserved (s : State) (n : Nat) :
    (advance s n).raw.g0.s31 = s.raw.g0.s31 := by
  induction n with
  | zero => rfl
  | succ n ih => exact Eq.trans (memoryB_step (advance s n)) ih

def harness : Task2.Trace.Harness where
  State := State
  seed := witness
  step := step
  memoryA := fun s => s.raw.g0.s30
  memoryB := fun s => s.raw.g0.s31
  sample := fun s =>
    let r := Task2.Imported.CandidateCore.evaluate (inputs s) s.raw
    { cycle := s.cycles, reset := decide (s.cycles < 4), start := s.start,
      startReady := r.outputs.o1 == 1, tokenValid := r.outputs.o2 == 1,
      doneReady := r.outputs.o0 == 1, payloadReady := true,
      payloadValid := r.outputs.o4 == 1, data := r.outputs.o3 }

end Task2.Imported.CandidateAdapter
namespace Task2.Imported
def candidate : Task2.Device where
  State := Task2.Imported.CandidateAdapter.State
  initial := Task2.Imported.CandidateAdapter.initial
  step := Task2.Imported.CandidateAdapter.step
  result := (·.observed)
end Task2.Imported
#print axioms Task2.Imported.CandidateAdapter.initial_exists
#print axioms Task2.Imported.CandidateAdapter.memoryA_preserved
#print axioms Task2.Imported.CandidateAdapter.memoryB_preserved
