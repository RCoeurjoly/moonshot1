/home/roland/moonshot1/experiments/task2-equivalence/build/hardware/candidate/rtl/main.sv
