import Task2.Imported.CandidateCuts1
import Task2.Imported.CandidateCuts2
import Task2.Imported.CandidateCuts4
import Task2.Imported.CandidateCuts6
import Task2.Imported.CandidateCuts32
import Task2.Imported.CandidateCuts33
import Task2.Imported.CandidateCuts34
import Task2.Imported.CandidateCuts35
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.CandidateTrace
theorem transition306 (a b : Task2.Words) (raw : Task2.Imported.CandidateCore.State) (seedStart : Bool) :
    Task2.Imported.CandidateAdapter.step (state306 a b raw seedStart) = state307 a b raw seedStart := by
  have h0 : Task2.Imported.CandidateCore.c2lChunk0 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw  = chunk31_0 a b raw seedStart := by
    kernel_exact cut31_0 a b raw seedStart
  have h1 : Task2.Imported.CandidateCore.c2lChunk1 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) = chunk23_1 a b raw seedStart := by
    kernel_exact cut28_1 a b raw seedStart
  have h2 : Task2.Imported.CandidateCore.c2lChunk2 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) = chunk306_2 a b raw seedStart := by
    kernel_exact cut306_2 a b raw seedStart
  have h3 : Task2.Imported.CandidateCore.c2lChunk3 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_2 a b raw seedStart) = chunk306_3 a b raw seedStart := by
    kernel_exact cut306_3 a b raw seedStart
  have h4 : Task2.Imported.CandidateCore.c2lChunk4 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) = chunk306_4 a b raw seedStart := by
    kernel_exact cut306_4 a b raw seedStart
  have h5 : Task2.Imported.CandidateCore.c2lChunk5 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_4 a b raw seedStart) = chunk306_5 a b raw seedStart := by
    kernel_exact cut306_5 a b raw seedStart
  have h6 : Task2.Imported.CandidateCore.c2lChunk6 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_4 a b raw seedStart) (chunk306_5 a b raw seedStart) = chunk306_6 a b raw seedStart := by
    kernel_exact cut306_6 a b raw seedStart
  have h7 : Task2.Imported.CandidateCore.c2lChunk7 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_4 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) = chunk306_7 a b raw seedStart := by
    kernel_exact cut306_7 a b raw seedStart
  have h8 : Task2.Imported.CandidateCore.c2lChunk8 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_4 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) (chunk306_7 a b raw seedStart) = chunk306_8 a b raw seedStart := by
    kernel_exact cut306_8 a b raw seedStart
  have h9 : Task2.Imported.CandidateCore.c2lChunk9 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_4 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) (chunk306_7 a b raw seedStart) (chunk306_8 a b raw seedStart) = chunk11_9 a b raw seedStart := by
    kernel_exact cut11_9 a b raw seedStart
  have h10 : Task2.Imported.CandidateCore.c2lChunk10 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_4 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) (chunk306_7 a b raw seedStart) (chunk306_8 a b raw seedStart) (chunk11_9 a b raw seedStart) = chunk306_10 a b raw seedStart := by
    kernel_exact cut306_10 a b raw seedStart
  have h11 : Task2.Imported.CandidateCore.c2lChunk11 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) (chunk306_8 a b raw seedStart) (chunk306_10 a b raw seedStart) = chunk306_11 a b raw seedStart := by
    kernel_exact cut306_11 a b raw seedStart
  have h12 : Task2.Imported.CandidateCore.c2lChunk12 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_4 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) (chunk306_11 a b raw seedStart) = chunk306_12 a b raw seedStart := by
    kernel_exact cut306_12 a b raw seedStart
  have h13 : Task2.Imported.CandidateCore.c2lChunk13 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_7 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk306_10 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk306_12 a b raw seedStart) = chunk306_13 a b raw seedStart := by
    kernel_exact cut306_13 a b raw seedStart
  have h14 : Task2.Imported.CandidateCore.c2lChunk14 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) (chunk306_8 a b raw seedStart) (chunk306_10 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk306_13 a b raw seedStart) = chunk306_14 a b raw seedStart := by
    kernel_exact cut306_14 a b raw seedStart
  have h15 : Task2.Imported.CandidateCore.c2lChunk15 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_4 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) (chunk306_7 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk306_14 a b raw seedStart) = chunk306_15 a b raw seedStart := by
    kernel_exact cut306_15 a b raw seedStart
  have h16 : Task2.Imported.CandidateCore.c2lChunk16 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_10 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk306_13 a b raw seedStart) (chunk306_15 a b raw seedStart) = chunk31_16 a b raw seedStart := by
    kernel_exact cut31_16 a b raw seedStart
  have h17 : Task2.Imported.CandidateCore.c2lChunk17 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_3 a b raw seedStart) (chunk11_9 a b raw seedStart) (chunk306_10 a b raw seedStart) (chunk306_13 a b raw seedStart) (chunk31_16 a b raw seedStart) = chunk306_17 a b raw seedStart := by
    kernel_exact cut306_17 a b raw seedStart
  have h18 : Task2.Imported.CandidateCore.c2lChunk18 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_6 a b raw seedStart) (chunk306_10 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk306_13 a b raw seedStart) (chunk306_14 a b raw seedStart) (chunk306_15 a b raw seedStart) (chunk306_17 a b raw seedStart) = chunk286_18 a b raw seedStart := by
    kernel_exact cut306_18 a b raw seedStart
  have h19 : Task2.Imported.CandidateCore.c2lChunk19 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk306_15 a b raw seedStart) (chunk31_16 a b raw seedStart) (chunk306_17 a b raw seedStart) (chunk286_18 a b raw seedStart) = chunk299_19 a b raw seedStart := by
    kernel_exact cut299_19 a b raw seedStart
  have h20 : Task2.Imported.CandidateCore.c2lChunk20 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk31_16 a b raw seedStart) (chunk306_17 a b raw seedStart) (chunk299_19 a b raw seedStart) = chunk27_20 a b raw seedStart := by
    kernel_exact cut28_20 a b raw seedStart
  have h21 : Task2.Imported.CandidateCore.c2lChunk21 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_13 a b raw seedStart) (chunk31_16 a b raw seedStart) (chunk306_17 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) = chunk306_21 a b raw seedStart := by
    kernel_exact cut306_21 a b raw seedStart
  have h22 : Task2.Imported.CandidateCore.c2lChunk22 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk306_15 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) = chunk30_22 a b raw seedStart := by
    kernel_exact cut30_22 a b raw seedStart
  have h23 : Task2.Imported.CandidateCore.c2lChunk23 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_14 a b raw seedStart) (chunk306_15 a b raw seedStart) (chunk31_16 a b raw seedStart) (chunk286_18 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk30_22 a b raw seedStart) = chunk295_23 a b raw seedStart := by
    kernel_exact cut295_23 a b raw seedStart
  have h24 : Task2.Imported.CandidateCore.c2lChunk24 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk306_15 a b raw seedStart) (chunk31_16 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk295_23 a b raw seedStart) = chunk1_24 a b raw seedStart := by
    kernel_exact cut16_24 a b raw seedStart
  have h25 : Task2.Imported.CandidateCore.c2lChunk25 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk306_17 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk1_24 a b raw seedStart) = chunk31_25 a b raw seedStart := by
    kernel_exact cut31_25 a b raw seedStart
  have h26 : Task2.Imported.CandidateCore.c2lChunk26 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk31_16 a b raw seedStart) (chunk306_17 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk30_22 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk31_25 a b raw seedStart) = chunk283_26 a b raw seedStart := by
    kernel_exact cut305_26 a b raw seedStart
  have h27 : Task2.Imported.CandidateCore.c2lChunk27 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk30_22 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk31_25 a b raw seedStart) (chunk283_26 a b raw seedStart) = chunk15_27 a b raw seedStart := by
    kernel_exact cut28_27 a b raw seedStart
  have h28 : Task2.Imported.CandidateCore.c2lChunk28 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk286_18 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk30_22 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk15_27 a b raw seedStart) = chunk297_28 a b raw seedStart := by
    kernel_exact cut303_28 a b raw seedStart
  have h29 : Task2.Imported.CandidateCore.c2lChunk29 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk306_11 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk30_22 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk31_25 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk297_28 a b raw seedStart) = chunk16_29 a b raw seedStart := by
    kernel_exact cut16_29 a b raw seedStart
  have h30 : Task2.Imported.CandidateCore.c2lChunk30 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk31_16 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk31_25 a b raw seedStart) (chunk283_26 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk16_29 a b raw seedStart) = chunk284_30 a b raw seedStart := by
    kernel_exact cut285_30 a b raw seedStart
  have h31 : Task2.Imported.CandidateCore.c2lChunk31 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk31_25 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk297_28 a b raw seedStart) (chunk16_29 a b raw seedStart) (chunk284_30 a b raw seedStart) = chunk297_31 a b raw seedStart := by
    kernel_exact cut297_31 a b raw seedStart
  have h32 : Task2.Imported.CandidateCore.c2lChunk32 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk31_16 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk16_29 a b raw seedStart) (chunk284_30 a b raw seedStart) (chunk297_31 a b raw seedStart) = chunk1_32 a b raw seedStart := by
    kernel_exact cut4_32 a b raw seedStart
  have h33 : Task2.Imported.CandidateCore.c2lChunk33 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_2 a b raw seedStart) (chunk306_5 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk284_30 a b raw seedStart) (chunk297_31 a b raw seedStart) (chunk1_32 a b raw seedStart) = chunk15_33 a b raw seedStart := by
    kernel_exact cut284_33 a b raw seedStart
  have h34 : Task2.Imported.CandidateCore.c2lChunk34 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk295_23 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk284_30 a b raw seedStart) (chunk297_31 a b raw seedStart) (chunk1_32 a b raw seedStart) (chunk15_33 a b raw seedStart) = chunk297_34 a b raw seedStart := by
    kernel_exact cut297_34 a b raw seedStart
  have h35 : Task2.Imported.CandidateCore.c2lChunk35 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk299_19 a b raw seedStart) (chunk27_20 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk1_24 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk284_30 a b raw seedStart) (chunk15_33 a b raw seedStart) (chunk297_34 a b raw seedStart) = chunk301_35 a b raw seedStart := by
    kernel_exact cut302_35 a b raw seedStart
  have h36 : Task2.Imported.CandidateCore.c2lChunk36 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk23_1 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk306_21 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk284_30 a b raw seedStart) (chunk1_32 a b raw seedStart) (chunk15_33 a b raw seedStart) (chunk301_35 a b raw seedStart) = chunk289_36 a b raw seedStart := by
    kernel_exact cut299_36 a b raw seedStart
  have h37 : Task2.Imported.CandidateCore.c2lChunk37 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk306_12 a b raw seedStart) (chunk15_27 a b raw seedStart) (chunk301_35 a b raw seedStart) (chunk289_36 a b raw seedStart) = chunk291_37 a b raw seedStart := by
    kernel_exact cut291_37 a b raw seedStart
  have h38 : Task2.Imported.CandidateCore.c2lChunk38 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk301_35 a b raw seedStart) (chunk289_36 a b raw seedStart) (chunk291_37 a b raw seedStart) = chunk292_38 a b raw seedStart := by
    kernel_exact cut292_38 a b raw seedStart
  have h39 : Task2.Imported.CandidateCore.c2lChunk39 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk301_35 a b raw seedStart) (chunk289_36 a b raw seedStart) (chunk291_37 a b raw seedStart) (chunk292_38 a b raw seedStart) = chunk293_39 a b raw seedStart := by
    kernel_exact cut293_39 a b raw seedStart
  have h40 : Task2.Imported.CandidateCore.c2lChunk40 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk301_35 a b raw seedStart) (chunk289_36 a b raw seedStart) (chunk291_37 a b raw seedStart) (chunk292_38 a b raw seedStart) (chunk293_39 a b raw seedStart) = chunk292_40 a b raw seedStart := by
    kernel_exact cut292_40 a b raw seedStart
  have h41 : Task2.Imported.CandidateCore.c2lChunk41 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk292_38 a b raw seedStart) (chunk293_39 a b raw seedStart) (chunk292_40 a b raw seedStart) = chunk295_41 a b raw seedStart := by
    kernel_exact cut295_41 a b raw seedStart
  have h42 : Task2.Imported.CandidateCore.c2lChunk42 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk292_38 a b raw seedStart) (chunk292_40 a b raw seedStart) (chunk295_41 a b raw seedStart) = chunk297_42 a b raw seedStart := by
    kernel_exact cut297_42 a b raw seedStart
  have h43 : Task2.Imported.CandidateCore.c2lChunk43 (Task2.Imported.CandidateAdapter.inputs (state306 a b raw seedStart)) (state306 a b raw seedStart).raw (chunk31_0 a b raw seedStart) (chunk292_38 a b raw seedStart) (chunk295_41 a b raw seedStart) (chunk297_42 a b raw seedStart) = chunk296_43 a b raw seedStart := by
    kernel_exact cut297_43 a b raw seedStart
  simp only [Task2.Imported.CandidateAdapter.step, Task2.Imported.CandidateCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43]
  kernel_rfl
#print axioms transition306
end Task2.Imported.CandidateTrace
