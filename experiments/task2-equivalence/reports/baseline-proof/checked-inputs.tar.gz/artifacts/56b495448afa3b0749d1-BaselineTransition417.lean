import Task2.Imported.BaselineCuts1
import Task2.Imported.BaselineCuts2
import Task2.Imported.BaselineCuts4
import Task2.Imported.BaselineCuts7
import Task2.Imported.BaselineCuts8
import Task2.Imported.BaselineCuts45
import Task2.Imported.BaselineCuts46
import Task2.Imported.BaselineCuts47
import Task2.Imported.BaselineCuts48
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.BaselineTrace
theorem transition417 (a b : Task2.Words) (raw : Task2.Imported.BaselineCore.State) (seedStart : Bool) :
    Task2.Imported.BaselineAdapter.step (state417 a b raw seedStart) = state418 a b raw seedStart := by
  have h0 : Task2.Imported.BaselineCore.c2lChunk0 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw  = chunk402_0 a b raw seedStart := by
    kernel_exact cut402_0 a b raw seedStart
  have h1 : Task2.Imported.BaselineCore.c2lChunk1 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) = chunk403_1 a b raw seedStart := by
    kernel_exact cut403_1 a b raw seedStart
  have h2 : Task2.Imported.BaselineCore.c2lChunk2 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) = chunk414_2 a b raw seedStart := by
    kernel_exact cut414_2 a b raw seedStart
  have h3 : Task2.Imported.BaselineCore.c2lChunk3 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) = chunk416_3 a b raw seedStart := by
    kernel_exact cut416_3 a b raw seedStart
  have h4 : Task2.Imported.BaselineCore.c2lChunk4 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) = chunk415_4 a b raw seedStart := by
    kernel_exact cut416_4 a b raw seedStart
  have h5 : Task2.Imported.BaselineCore.c2lChunk5 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk415_4 a b raw seedStart) = chunk403_5 a b raw seedStart := by
    kernel_exact cut403_5 a b raw seedStart
  have h6 : Task2.Imported.BaselineCore.c2lChunk6 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk415_4 a b raw seedStart) (chunk403_5 a b raw seedStart) = chunk32_6 a b raw seedStart := by
    kernel_exact cut416_6 a b raw seedStart
  have h7 : Task2.Imported.BaselineCore.c2lChunk7 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk415_4 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk32_6 a b raw seedStart) = chunk413_7 a b raw seedStart := by
    kernel_exact cut414_7 a b raw seedStart
  have h8 : Task2.Imported.BaselineCore.c2lChunk8 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk415_4 a b raw seedStart) (chunk32_6 a b raw seedStart) (chunk413_7 a b raw seedStart) = chunk33_8 a b raw seedStart := by
    kernel_exact cut33_8 a b raw seedStart
  have h9 : Task2.Imported.BaselineCore.c2lChunk9 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk415_4 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk32_6 a b raw seedStart) (chunk33_8 a b raw seedStart) = chunk33_9 a b raw seedStart := by
    kernel_exact cut33_9 a b raw seedStart
  have h10 : Task2.Imported.BaselineCore.c2lChunk10 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk415_4 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk413_7 a b raw seedStart) (chunk33_9 a b raw seedStart) = chunk417_10 a b raw seedStart := by
    kernel_exact cut417_10 a b raw seedStart
  have h11 : Task2.Imported.BaselineCore.c2lChunk11 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk32_6 a b raw seedStart) (chunk413_7 a b raw seedStart) (chunk33_8 a b raw seedStart) (chunk417_10 a b raw seedStart) = chunk417_11 a b raw seedStart := by
    kernel_exact cut417_11 a b raw seedStart
  have h12 : Task2.Imported.BaselineCore.c2lChunk12 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk415_4 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk413_7 a b raw seedStart) (chunk33_8 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_11 a b raw seedStart) = chunk417_12 a b raw seedStart := by
    kernel_exact cut417_12 a b raw seedStart
  have h13 : Task2.Imported.BaselineCore.c2lChunk13 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk32_6 a b raw seedStart) (chunk413_7 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_12 a b raw seedStart) = chunk417_13 a b raw seedStart := by
    kernel_exact cut417_13 a b raw seedStart
  have h14 : Task2.Imported.BaselineCore.c2lChunk14 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk33_8 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_11 a b raw seedStart) (chunk417_13 a b raw seedStart) = chunk417_14 a b raw seedStart := by
    kernel_exact cut417_14 a b raw seedStart
  have h15 : Task2.Imported.BaselineCore.c2lChunk15 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_12 a b raw seedStart) (chunk417_13 a b raw seedStart) (chunk417_14 a b raw seedStart) = chunk417_15 a b raw seedStart := by
    kernel_exact cut417_15 a b raw seedStart
  have h16 : Task2.Imported.BaselineCore.c2lChunk16 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk415_4 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk32_6 a b raw seedStart) (chunk413_7 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_12 a b raw seedStart) (chunk417_13 a b raw seedStart) (chunk417_15 a b raw seedStart) = chunk4_16 a b raw seedStart := by
    kernel_exact cut42_16 a b raw seedStart
  have h17 : Task2.Imported.BaselineCore.c2lChunk17 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_13 a b raw seedStart) (chunk4_16 a b raw seedStart) = chunk417_17 a b raw seedStart := by
    kernel_exact cut417_17 a b raw seedStart
  have h18 : Task2.Imported.BaselineCore.c2lChunk18 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk416_3 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_13 a b raw seedStart) (chunk417_17 a b raw seedStart) = chunk4_18 a b raw seedStart := by
    kernel_exact cut5_18 a b raw seedStart
  have h19 : Task2.Imported.BaselineCore.c2lChunk19 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_11 a b raw seedStart) (chunk417_14 a b raw seedStart) (chunk417_15 a b raw seedStart) (chunk4_18 a b raw seedStart) = chunk414_19 a b raw seedStart := by
    kernel_exact cut414_19 a b raw seedStart
  have h20 : Task2.Imported.BaselineCore.c2lChunk20 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_12 a b raw seedStart) (chunk417_15 a b raw seedStart) (chunk417_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk414_19 a b raw seedStart) = chunk417_20 a b raw seedStart := by
    kernel_exact cut417_20 a b raw seedStart
  have h21 : Task2.Imported.BaselineCore.c2lChunk21 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_13 a b raw seedStart) (chunk417_17 a b raw seedStart) (chunk417_20 a b raw seedStart) = chunk413_21 a b raw seedStart := by
    kernel_exact cut413_21 a b raw seedStart
  have h22 : Task2.Imported.BaselineCore.c2lChunk22 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_13 a b raw seedStart) (chunk417_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk413_21 a b raw seedStart) = chunk417_22 a b raw seedStart := by
    kernel_exact cut417_22 a b raw seedStart
  have h23 : Task2.Imported.BaselineCore.c2lChunk23 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_15 a b raw seedStart) (chunk417_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk413_21 a b raw seedStart) (chunk417_22 a b raw seedStart) = chunk11_23 a b raw seedStart := by
    kernel_exact cut11_23 a b raw seedStart
  have h24 : Task2.Imported.BaselineCore.c2lChunk24 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_14 a b raw seedStart) (chunk417_15 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk11_23 a b raw seedStart) = chunk417_24 a b raw seedStart := by
    kernel_exact cut417_24 a b raw seedStart
  have h25 : Task2.Imported.BaselineCore.c2lChunk25 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk417_24 a b raw seedStart) = chunk15_25 a b raw seedStart := by
    kernel_exact cut417_25 a b raw seedStart
  have h26 : Task2.Imported.BaselineCore.c2lChunk26 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk417_10 a b raw seedStart) (chunk417_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk413_21 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk15_25 a b raw seedStart) = chunk15_26 a b raw seedStart := by
    kernel_exact cut413_26 a b raw seedStart
  have h27 : Task2.Imported.BaselineCore.c2lChunk27 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk417_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk413_21 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk15_26 a b raw seedStart) = chunk417_27 a b raw seedStart := by
    kernel_exact cut417_27 a b raw seedStart
  have h28 : Task2.Imported.BaselineCore.c2lChunk28 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk417_24 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk417_27 a b raw seedStart) = chunk412_28 a b raw seedStart := by
    kernel_exact cut413_28 a b raw seedStart
  have h29 : Task2.Imported.BaselineCore.c2lChunk29 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk15_26 a b raw seedStart) (chunk417_27 a b raw seedStart) (chunk412_28 a b raw seedStart) = chunk15_29 a b raw seedStart := by
    kernel_exact cut403_29 a b raw seedStart
  have h30 : Task2.Imported.BaselineCore.c2lChunk30 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk413_21 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk15_26 a b raw seedStart) (chunk15_29 a b raw seedStart) = chunk401_30 a b raw seedStart := by
    kernel_exact cut402_30 a b raw seedStart
  have h31 : Task2.Imported.BaselineCore.c2lChunk31 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk417_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk401_30 a b raw seedStart) = chunk409_31 a b raw seedStart := by
    kernel_exact cut410_31 a b raw seedStart
  have h32 : Task2.Imported.BaselineCore.c2lChunk32 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk412_28 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk409_31 a b raw seedStart) = chunk414_32 a b raw seedStart := by
    kernel_exact cut414_32 a b raw seedStart
  have h33 : Task2.Imported.BaselineCore.c2lChunk33 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk417_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk414_32 a b raw seedStart) = chunk16_33 a b raw seedStart := by
    kernel_exact cut17_33 a b raw seedStart
  have h34 : Task2.Imported.BaselineCore.c2lChunk34 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk417_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk409_31 a b raw seedStart) (chunk414_32 a b raw seedStart) (chunk16_33 a b raw seedStart) = chunk1_34 a b raw seedStart := by
    kernel_exact cut4_34 a b raw seedStart
  have h35 : Task2.Imported.BaselineCore.c2lChunk35 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_2 a b raw seedStart) (chunk403_5 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk409_31 a b raw seedStart) (chunk414_32 a b raw seedStart) (chunk1_34 a b raw seedStart) = chunk414_35 a b raw seedStart := by
    kernel_exact cut415_35 a b raw seedStart
  have h36 : Task2.Imported.BaselineCore.c2lChunk36 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk414_32 a b raw seedStart) (chunk16_33 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk414_35 a b raw seedStart) = chunk413_36 a b raw seedStart := by
    kernel_exact cut414_36 a b raw seedStart
  have h37 : Task2.Imported.BaselineCore.c2lChunk37 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk414_19 a b raw seedStart) (chunk417_20 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk414_35 a b raw seedStart) (chunk413_36 a b raw seedStart) = chunk415_37 a b raw seedStart := by
    kernel_exact cut415_37 a b raw seedStart
  have h38 : Task2.Imported.BaselineCore.c2lChunk38 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk417_12 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk415_37 a b raw seedStart) = chunk415_38 a b raw seedStart := by
    kernel_exact cut415_38 a b raw seedStart
  have h39 : Task2.Imported.BaselineCore.c2lChunk39 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk417_12 a b raw seedStart) (chunk415_38 a b raw seedStart) = chunk414_39 a b raw seedStart := by
    kernel_exact cut415_39 a b raw seedStart
  have h40 : Task2.Imported.BaselineCore.c2lChunk40 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk417_12 a b raw seedStart) (chunk415_38 a b raw seedStart) (chunk414_39 a b raw seedStart) = chunk415_40 a b raw seedStart := by
    kernel_exact cut415_40 a b raw seedStart
  have h41 : Task2.Imported.BaselineCore.c2lChunk41 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk417_12 a b raw seedStart) (chunk415_38 a b raw seedStart) (chunk415_40 a b raw seedStart) = chunk415_41 a b raw seedStart := by
    kernel_exact cut415_41 a b raw seedStart
  have h42 : Task2.Imported.BaselineCore.c2lChunk42 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk403_1 a b raw seedStart) (chunk417_12 a b raw seedStart) (chunk417_22 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk415_37 a b raw seedStart) (chunk415_38 a b raw seedStart) (chunk415_41 a b raw seedStart) = chunk414_42 a b raw seedStart := by
    kernel_exact cut415_42 a b raw seedStart
  have h43 : Task2.Imported.BaselineCore.c2lChunk43 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_12 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk415_37 a b raw seedStart) (chunk415_38 a b raw seedStart) (chunk414_42 a b raw seedStart) = chunk416_43 a b raw seedStart := by
    kernel_exact cut416_43 a b raw seedStart
  have h44 : Task2.Imported.BaselineCore.c2lChunk44 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk415_37 a b raw seedStart) (chunk414_42 a b raw seedStart) (chunk416_43 a b raw seedStart) = chunk417_44 a b raw seedStart := by
    kernel_exact cut417_44 a b raw seedStart
  have h45 : Task2.Imported.BaselineCore.c2lChunk45 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk415_38 a b raw seedStart) (chunk414_42 a b raw seedStart) (chunk416_43 a b raw seedStart) (chunk417_44 a b raw seedStart) = chunk417_45 a b raw seedStart := by
    kernel_exact cut417_45 a b raw seedStart
  have h46 : Task2.Imported.BaselineCore.c2lChunk46 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk415_38 a b raw seedStart) (chunk414_42 a b raw seedStart) (chunk416_43 a b raw seedStart) (chunk417_44 a b raw seedStart) (chunk417_45 a b raw seedStart) = chunk417_46 a b raw seedStart := by
    kernel_exact cut417_46 a b raw seedStart
  have h47 : Task2.Imported.BaselineCore.c2lChunk47 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_44 a b raw seedStart) (chunk417_45 a b raw seedStart) (chunk417_46 a b raw seedStart) = chunk395_47 a b raw seedStart := by
    kernel_exact cut395_47 a b raw seedStart
  have h48 : Task2.Imported.BaselineCore.c2lChunk48 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_44 a b raw seedStart) (chunk417_46 a b raw seedStart) (chunk395_47 a b raw seedStart) = chunk395_48 a b raw seedStart := by
    kernel_exact cut395_48 a b raw seedStart
  have h49 : Task2.Imported.BaselineCore.c2lChunk49 (Task2.Imported.BaselineAdapter.inputs (state417 a b raw seedStart)) (state417 a b raw seedStart).raw (chunk402_0 a b raw seedStart) (chunk417_44 a b raw seedStart) (chunk395_47 a b raw seedStart) (chunk395_48 a b raw seedStart) = chunk396_49 a b raw seedStart := by
    kernel_exact cut397_49 a b raw seedStart
  simp only [Task2.Imported.BaselineAdapter.step, Task2.Imported.BaselineCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43, h44, h45, h46, h47, h48, h49]
  kernel_rfl
#print axioms transition417
end Task2.Imported.BaselineTrace
