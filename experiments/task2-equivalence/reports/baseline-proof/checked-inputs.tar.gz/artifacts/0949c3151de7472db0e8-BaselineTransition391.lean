import Task2.Imported.BaselineCuts1
import Task2.Imported.BaselineCuts2
import Task2.Imported.BaselineCuts4
import Task2.Imported.BaselineCuts5
import Task2.Imported.BaselineCuts6
import Task2.Imported.BaselineCuts7
import Task2.Imported.BaselineCuts8
import Task2.Imported.BaselineCuts42
import Task2.Imported.BaselineCuts43
import Task2.Imported.BaselineCuts44
import Task2.Imported.BaselineCuts45
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.BaselineTrace
theorem transition391 (a b : Task2.Words) (raw : Task2.Imported.BaselineCore.State) (seedStart : Bool) :
    Task2.Imported.BaselineAdapter.step (state391 a b raw seedStart) = state392 a b raw seedStart := by
  have h0 : Task2.Imported.BaselineCore.c2lChunk0 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw  = chunk33_0 a b raw seedStart := by
    kernel_exact cut33_0 a b raw seedStart
  have h1 : Task2.Imported.BaselineCore.c2lChunk1 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) = chunk386_1 a b raw seedStart := by
    kernel_exact cut386_1 a b raw seedStart
  have h2 : Task2.Imported.BaselineCore.c2lChunk2 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) = chunk388_2 a b raw seedStart := by
    kernel_exact cut388_2 a b raw seedStart
  have h3 : Task2.Imported.BaselineCore.c2lChunk3 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) = chunk386_3 a b raw seedStart := by
    kernel_exact cut386_3 a b raw seedStart
  have h4 : Task2.Imported.BaselineCore.c2lChunk4 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) = chunk387_4 a b raw seedStart := by
    kernel_exact cut387_4 a b raw seedStart
  have h5 : Task2.Imported.BaselineCore.c2lChunk5 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) = chunk31_5 a b raw seedStart := by
    kernel_exact cut32_5 a b raw seedStart
  have h6 : Task2.Imported.BaselineCore.c2lChunk6 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk31_5 a b raw seedStart) = chunk382_6 a b raw seedStart := by
    kernel_exact cut382_6 a b raw seedStart
  have h7 : Task2.Imported.BaselineCore.c2lChunk7 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk382_6 a b raw seedStart) = chunk387_7 a b raw seedStart := by
    kernel_exact cut388_7 a b raw seedStart
  have h8 : Task2.Imported.BaselineCore.c2lChunk8 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk387_7 a b raw seedStart) = chunk383_8 a b raw seedStart := by
    kernel_exact cut383_8 a b raw seedStart
  have h9 : Task2.Imported.BaselineCore.c2lChunk9 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk383_8 a b raw seedStart) = chunk33_9 a b raw seedStart := by
    kernel_exact cut33_9 a b raw seedStart
  have h10 : Task2.Imported.BaselineCore.c2lChunk10 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk33_9 a b raw seedStart) = chunk389_10 a b raw seedStart := by
    kernel_exact cut389_10 a b raw seedStart
  have h11 : Task2.Imported.BaselineCore.c2lChunk11 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk383_8 a b raw seedStart) (chunk389_10 a b raw seedStart) = chunk384_11 a b raw seedStart := by
    kernel_exact cut384_11 a b raw seedStart
  have h12 : Task2.Imported.BaselineCore.c2lChunk12 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk383_8 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk384_11 a b raw seedStart) = chunk391_12 a b raw seedStart := by
    kernel_exact cut391_12 a b raw seedStart
  have h13 : Task2.Imported.BaselineCore.c2lChunk13 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk391_12 a b raw seedStart) = chunk382_13 a b raw seedStart := by
    kernel_exact cut384_13 a b raw seedStart
  have h14 : Task2.Imported.BaselineCore.c2lChunk14 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk383_8 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk384_11 a b raw seedStart) (chunk382_13 a b raw seedStart) = chunk385_14 a b raw seedStart := by
    kernel_exact cut385_14 a b raw seedStart
  have h15 : Task2.Imported.BaselineCore.c2lChunk15 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk391_12 a b raw seedStart) (chunk382_13 a b raw seedStart) (chunk385_14 a b raw seedStart) = chunk391_15 a b raw seedStart := by
    kernel_exact cut391_15 a b raw seedStart
  have h16 : Task2.Imported.BaselineCore.c2lChunk16 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk387_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk382_6 a b raw seedStart) (chunk387_7 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk391_12 a b raw seedStart) (chunk382_13 a b raw seedStart) (chunk391_15 a b raw seedStart) = chunk31_16 a b raw seedStart := by
    kernel_exact cut32_16 a b raw seedStart
  have h17 : Task2.Imported.BaselineCore.c2lChunk17 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk382_13 a b raw seedStart) (chunk31_16 a b raw seedStart) = chunk385_17 a b raw seedStart := by
    kernel_exact cut385_17 a b raw seedStart
  have h18 : Task2.Imported.BaselineCore.c2lChunk18 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk386_3 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk382_13 a b raw seedStart) (chunk385_17 a b raw seedStart) = chunk20_18 a b raw seedStart := by
    kernel_exact cut23_18 a b raw seedStart
  have h19 : Task2.Imported.BaselineCore.c2lChunk19 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk384_11 a b raw seedStart) (chunk385_14 a b raw seedStart) (chunk391_15 a b raw seedStart) (chunk20_18 a b raw seedStart) = chunk389_19 a b raw seedStart := by
    kernel_exact cut389_19 a b raw seedStart
  have h20 : Task2.Imported.BaselineCore.c2lChunk20 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk391_12 a b raw seedStart) (chunk391_15 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk389_19 a b raw seedStart) = chunk367_20 a b raw seedStart := by
    kernel_exact cut368_20 a b raw seedStart
  have h21 : Task2.Imported.BaselineCore.c2lChunk21 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk382_13 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk367_20 a b raw seedStart) = chunk39_21 a b raw seedStart := by
    kernel_exact cut39_21 a b raw seedStart
  have h22 : Task2.Imported.BaselineCore.c2lChunk22 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk382_13 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk39_21 a b raw seedStart) = chunk384_22 a b raw seedStart := by
    kernel_exact cut385_22 a b raw seedStart
  have h23 : Task2.Imported.BaselineCore.c2lChunk23 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk391_15 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk39_21 a b raw seedStart) (chunk384_22 a b raw seedStart) = chunk11_23 a b raw seedStart := by
    kernel_exact cut11_23 a b raw seedStart
  have h24 : Task2.Imported.BaselineCore.c2lChunk24 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk385_14 a b raw seedStart) (chunk391_15 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk11_23 a b raw seedStart) = chunk387_24 a b raw seedStart := by
    kernel_exact cut387_24 a b raw seedStart
  have h25 : Task2.Imported.BaselineCore.c2lChunk25 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk387_24 a b raw seedStart) = chunk41_25 a b raw seedStart := by
    kernel_exact cut41_25 a b raw seedStart
  have h26 : Task2.Imported.BaselineCore.c2lChunk26 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk389_10 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk39_21 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk41_25 a b raw seedStart) = chunk18_26 a b raw seedStart := by
    kernel_exact cut22_26 a b raw seedStart
  have h27 : Task2.Imported.BaselineCore.c2lChunk27 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk39_21 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk18_26 a b raw seedStart) = chunk383_27 a b raw seedStart := by
    kernel_exact cut388_27 a b raw seedStart
  have h28 : Task2.Imported.BaselineCore.c2lChunk28 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk387_24 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk383_27 a b raw seedStart) = chunk390_28 a b raw seedStart := by
    kernel_exact cut391_28 a b raw seedStart
  have h29 : Task2.Imported.BaselineCore.c2lChunk29 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk18_26 a b raw seedStart) (chunk383_27 a b raw seedStart) (chunk390_28 a b raw seedStart) = chunk15_29 a b raw seedStart := by
    kernel_exact cut16_29 a b raw seedStart
  have h30 : Task2.Imported.BaselineCore.c2lChunk30 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk39_21 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk18_26 a b raw seedStart) (chunk15_29 a b raw seedStart) = chunk27_30 a b raw seedStart := by
    kernel_exact cut28_30 a b raw seedStart
  have h31 : Task2.Imported.BaselineCore.c2lChunk31 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk383_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk27_30 a b raw seedStart) = chunk384_31 a b raw seedStart := by
    kernel_exact cut385_31 a b raw seedStart
  have h32 : Task2.Imported.BaselineCore.c2lChunk32 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk385_17 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk11_23 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk390_28 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk384_31 a b raw seedStart) = chunk389_32 a b raw seedStart := by
    kernel_exact cut391_32 a b raw seedStart
  have h33 : Task2.Imported.BaselineCore.c2lChunk33 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk383_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk389_32 a b raw seedStart) = chunk16_33 a b raw seedStart := by
    kernel_exact cut17_33 a b raw seedStart
  have h34 : Task2.Imported.BaselineCore.c2lChunk34 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk20_18 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk383_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk384_31 a b raw seedStart) (chunk389_32 a b raw seedStart) (chunk16_33 a b raw seedStart) = chunk1_34 a b raw seedStart := by
    kernel_exact cut4_34 a b raw seedStart
  have h35 : Task2.Imported.BaselineCore.c2lChunk35 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk388_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk384_31 a b raw seedStart) (chunk389_32 a b raw seedStart) (chunk1_34 a b raw seedStart) = chunk389_35 a b raw seedStart := by
    kernel_exact cut390_35 a b raw seedStart
  have h36 : Task2.Imported.BaselineCore.c2lChunk36 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk389_32 a b raw seedStart) (chunk16_33 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk389_35 a b raw seedStart) = chunk388_36 a b raw seedStart := by
    kernel_exact cut389_36 a b raw seedStart
  have h37 : Task2.Imported.BaselineCore.c2lChunk37 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk389_19 a b raw seedStart) (chunk367_20 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk41_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk389_35 a b raw seedStart) (chunk388_36 a b raw seedStart) = chunk390_37 a b raw seedStart := by
    kernel_exact cut390_37 a b raw seedStart
  have h38 : Task2.Imported.BaselineCore.c2lChunk38 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk391_12 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk390_37 a b raw seedStart) = chunk390_38 a b raw seedStart := by
    kernel_exact cut390_38 a b raw seedStart
  have h39 : Task2.Imported.BaselineCore.c2lChunk39 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk391_12 a b raw seedStart) (chunk390_38 a b raw seedStart) = chunk389_39 a b raw seedStart := by
    kernel_exact cut390_39 a b raw seedStart
  have h40 : Task2.Imported.BaselineCore.c2lChunk40 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk391_12 a b raw seedStart) (chunk390_38 a b raw seedStart) (chunk389_39 a b raw seedStart) = chunk390_40 a b raw seedStart := by
    kernel_exact cut390_40 a b raw seedStart
  have h41 : Task2.Imported.BaselineCore.c2lChunk41 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk391_12 a b raw seedStart) (chunk390_38 a b raw seedStart) (chunk390_40 a b raw seedStart) = chunk390_41 a b raw seedStart := by
    kernel_exact cut390_41 a b raw seedStart
  have h42 : Task2.Imported.BaselineCore.c2lChunk42 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk386_1 a b raw seedStart) (chunk391_12 a b raw seedStart) (chunk384_22 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk390_37 a b raw seedStart) (chunk390_38 a b raw seedStart) (chunk390_41 a b raw seedStart) = chunk389_42 a b raw seedStart := by
    kernel_exact cut390_42 a b raw seedStart
  have h43 : Task2.Imported.BaselineCore.c2lChunk43 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk391_12 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk390_37 a b raw seedStart) (chunk390_38 a b raw seedStart) (chunk389_42 a b raw seedStart) = chunk391_43 a b raw seedStart := by
    kernel_exact cut391_43 a b raw seedStart
  have h44 : Task2.Imported.BaselineCore.c2lChunk44 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk390_37 a b raw seedStart) (chunk389_42 a b raw seedStart) (chunk391_43 a b raw seedStart) = chunk391_44 a b raw seedStart := by
    kernel_exact cut391_44 a b raw seedStart
  have h45 : Task2.Imported.BaselineCore.c2lChunk45 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk390_38 a b raw seedStart) (chunk389_42 a b raw seedStart) (chunk391_43 a b raw seedStart) (chunk391_44 a b raw seedStart) = chunk368_45 a b raw seedStart := by
    kernel_exact cut368_45 a b raw seedStart
  have h46 : Task2.Imported.BaselineCore.c2lChunk46 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk390_38 a b raw seedStart) (chunk389_42 a b raw seedStart) (chunk391_43 a b raw seedStart) (chunk391_44 a b raw seedStart) (chunk368_45 a b raw seedStart) = chunk367_46 a b raw seedStart := by
    kernel_exact cut367_46 a b raw seedStart
  have h47 : Task2.Imported.BaselineCore.c2lChunk47 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk391_44 a b raw seedStart) (chunk368_45 a b raw seedStart) (chunk367_46 a b raw seedStart) = chunk370_47 a b raw seedStart := by
    kernel_exact cut370_47 a b raw seedStart
  have h48 : Task2.Imported.BaselineCore.c2lChunk48 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk391_44 a b raw seedStart) (chunk367_46 a b raw seedStart) (chunk370_47 a b raw seedStart) = chunk370_48 a b raw seedStart := by
    kernel_exact cut370_48 a b raw seedStart
  have h49 : Task2.Imported.BaselineCore.c2lChunk49 (Task2.Imported.BaselineAdapter.inputs (state391 a b raw seedStart)) (state391 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk391_44 a b raw seedStart) (chunk370_47 a b raw seedStart) (chunk370_48 a b raw seedStart) = chunk371_49 a b raw seedStart := by
    kernel_exact cut372_49 a b raw seedStart
  simp only [Task2.Imported.BaselineAdapter.step, Task2.Imported.BaselineCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43, h44, h45, h46, h47, h48, h49]
  kernel_rfl
#print axioms transition391
end Task2.Imported.BaselineTrace
