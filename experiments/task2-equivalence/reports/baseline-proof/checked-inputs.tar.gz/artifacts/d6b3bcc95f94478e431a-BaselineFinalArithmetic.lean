import Task2.Imported.BaselineTrace
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.BaselineTrace
theorem final_word (a b : Task2.Words) (raw : Task2.Imported.BaselineCore.State) (seedStart : Bool) : (v4743 a b raw seedStart) = Task2.dot32 a b := by
  simp [v3166, v3167, v3168, v3265, v3266, v3267, v3330, v3365, v3366, v3367, v3431, v3466, v3467, v3468, v3532, v3567, v3568, v3569, v3633, v3668, v3669, v3670, v3734, v3769, v3770, v3771, v3835, v3870, v3871, v3872, v3936, v3971, v3972, v3973, v4037, v4072, v4073, v4074, v4138, v4173, v4174, v4175, v4239, v4274, v4275, v4276, v4340, v4375, v4376, v4377, v4441, v4476, v4477, v4478, v4542, v4577, v4578, v4579, v4643, v4677, v4678, v4679, v4743, Task2.dot32, List.finRange, List.ofFn, Fin.foldr, Fin.foldr.loop, BitVec.mul_comm]
#print axioms final_word
end Task2.Imported.BaselineTrace
