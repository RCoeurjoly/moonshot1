import Task2.Imported.BaselineTrace
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.BaselineTrace
theorem initial_parameterization (a b : Task2.Words) (s : Task2.Imported.BaselineAdapter.State) (h : Task2.Imported.BaselineAdapter.initial a b s) :
    s = state0 a b s.raw s.start := by
  rcases s with ⟨raw, cycles, start, observed⟩
  obtain ⟨hc, ho, _, ha, hb⟩ := h
  dsimp only at hc ho ha hb
  subst cycles
  subst observed
  rcases raw with ⟨g0, g1, g2, g3⟩
  cases g0
  simp_all [state0]
#print axioms initial_parameterization
end Task2.Imported.BaselineTrace
