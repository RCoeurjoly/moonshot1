import Task2.Imported.BaselineCuts1
import Task2.Imported.BaselineCuts2
import Task2.Imported.BaselineCuts3
import Task2.Imported.BaselineCuts10
import Task2.Imported.BaselineCuts48
import Task2.Imported.BaselineCuts49
import Task2.Imported.BaselineCuts50
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.BaselineTrace
theorem transition430 (a b : Task2.Words) (raw : Task2.Imported.BaselineCore.State) (seedStart : Bool) :
    Task2.Imported.BaselineAdapter.step (state430 a b raw seedStart) = state431 a b raw seedStart := by
  have h0 : Task2.Imported.BaselineCore.c2lChunk0 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw  = chunk427_0 a b raw seedStart := by
    kernel_exact cut427_0 a b raw seedStart
  have h1 : Task2.Imported.BaselineCore.c2lChunk1 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) = chunk427_1 a b raw seedStart := by
    kernel_exact cut427_1 a b raw seedStart
  have h2 : Task2.Imported.BaselineCore.c2lChunk2 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) = chunk8_2 a b raw seedStart := by
    kernel_exact cut9_2 a b raw seedStart
  have h3 : Task2.Imported.BaselineCore.c2lChunk3 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) = chunk430_3 a b raw seedStart := by
    kernel_exact cut430_3 a b raw seedStart
  have h4 : Task2.Imported.BaselineCore.c2lChunk4 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) = chunk11_4 a b raw seedStart := by
    kernel_exact cut430_4 a b raw seedStart
  have h5 : Task2.Imported.BaselineCore.c2lChunk5 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk11_4 a b raw seedStart) = chunk9_5 a b raw seedStart := by
    kernel_exact cut9_5 a b raw seedStart
  have h6 : Task2.Imported.BaselineCore.c2lChunk6 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) = chunk430_6 a b raw seedStart := by
    kernel_exact cut430_6 a b raw seedStart
  have h7 : Task2.Imported.BaselineCore.c2lChunk7 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk430_6 a b raw seedStart) = chunk12_7 a b raw seedStart := by
    kernel_exact cut13_7 a b raw seedStart
  have h8 : Task2.Imported.BaselineCore.c2lChunk8 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk430_6 a b raw seedStart) (chunk12_7 a b raw seedStart) = chunk58_8 a b raw seedStart := by
    kernel_exact cut58_8 a b raw seedStart
  have h9 : Task2.Imported.BaselineCore.c2lChunk9 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk430_6 a b raw seedStart) (chunk58_8 a b raw seedStart) = chunk1_9 a b raw seedStart := by
    kernel_exact cut4_9 a b raw seedStart
  have h10 : Task2.Imported.BaselineCore.c2lChunk10 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk1_9 a b raw seedStart) = chunk13_10 a b raw seedStart := by
    kernel_exact cut13_10 a b raw seedStart
  have h11 : Task2.Imported.BaselineCore.c2lChunk11 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk430_6 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk58_8 a b raw seedStart) (chunk13_10 a b raw seedStart) = chunk428_11 a b raw seedStart := by
    kernel_exact cut429_11 a b raw seedStart
  have h12 : Task2.Imported.BaselineCore.c2lChunk12 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk58_8 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk428_11 a b raw seedStart) = chunk427_12 a b raw seedStart := by
    kernel_exact cut428_12 a b raw seedStart
  have h13 : Task2.Imported.BaselineCore.c2lChunk13 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk430_6 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk1_9 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk427_12 a b raw seedStart) = chunk14_13 a b raw seedStart := by
    kernel_exact cut14_13 a b raw seedStart
  have h14 : Task2.Imported.BaselineCore.c2lChunk14 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk58_8 a b raw seedStart) (chunk1_9 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk428_11 a b raw seedStart) (chunk14_13 a b raw seedStart) = chunk430_14 a b raw seedStart := by
    kernel_exact cut430_14 a b raw seedStart
  have h15 : Task2.Imported.BaselineCore.c2lChunk15 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk1_9 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk427_12 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk430_14 a b raw seedStart) = chunk418_15 a b raw seedStart := by
    kernel_exact cut418_15 a b raw seedStart
  have h16 : Task2.Imported.BaselineCore.c2lChunk16 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk11_4 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk430_6 a b raw seedStart) (chunk12_7 a b raw seedStart) (chunk1_9 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk427_12 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk418_15 a b raw seedStart) = chunk4_16 a b raw seedStart := by
    kernel_exact cut4_16 a b raw seedStart
  have h17 : Task2.Imported.BaselineCore.c2lChunk17 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk4_16 a b raw seedStart) = chunk430_17 a b raw seedStart := by
    kernel_exact cut430_17 a b raw seedStart
  have h18 : Task2.Imported.BaselineCore.c2lChunk18 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk430_3 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk430_17 a b raw seedStart) = chunk4_18 a b raw seedStart := by
    kernel_exact cut5_18 a b raw seedStart
  have h19 : Task2.Imported.BaselineCore.c2lChunk19 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk428_11 a b raw seedStart) (chunk430_14 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk4_18 a b raw seedStart) = chunk430_19 a b raw seedStart := by
    kernel_exact cut430_19 a b raw seedStart
  have h20 : Task2.Imported.BaselineCore.c2lChunk20 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_12 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk430_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk430_19 a b raw seedStart) = chunk423_20 a b raw seedStart := by
    kernel_exact cut423_20 a b raw seedStart
  have h21 : Task2.Imported.BaselineCore.c2lChunk21 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk430_17 a b raw seedStart) (chunk423_20 a b raw seedStart) = chunk422_21 a b raw seedStart := by
    kernel_exact cut422_21 a b raw seedStart
  have h22 : Task2.Imported.BaselineCore.c2lChunk22 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk14_13 a b raw seedStart) (chunk430_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk422_21 a b raw seedStart) = chunk428_22 a b raw seedStart := by
    kernel_exact cut428_22 a b raw seedStart
  have h23 : Task2.Imported.BaselineCore.c2lChunk23 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk1_9 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk430_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk422_21 a b raw seedStart) (chunk428_22 a b raw seedStart) = chunk5_23 a b raw seedStart := by
    kernel_exact cut6_23 a b raw seedStart
  have h24 : Task2.Imported.BaselineCore.c2lChunk24 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk430_14 a b raw seedStart) (chunk418_15 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk5_23 a b raw seedStart) = chunk430_24 a b raw seedStart := by
    kernel_exact cut430_24 a b raw seedStart
  have h25 : Task2.Imported.BaselineCore.c2lChunk25 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk430_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk430_24 a b raw seedStart) = chunk1_25 a b raw seedStart := by
    kernel_exact cut426_25 a b raw seedStart
  have h26 : Task2.Imported.BaselineCore.c2lChunk26 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk13_10 a b raw seedStart) (chunk430_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk422_21 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk1_25 a b raw seedStart) = chunk1_26 a b raw seedStart := by
    kernel_exact cut426_26 a b raw seedStart
  have h27 : Task2.Imported.BaselineCore.c2lChunk27 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk430_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk422_21 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk5_23 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk1_26 a b raw seedStart) = chunk7_27 a b raw seedStart := by
    kernel_exact cut428_27 a b raw seedStart
  have h28 : Task2.Imported.BaselineCore.c2lChunk28 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk1_9 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk5_23 a b raw seedStart) (chunk430_24 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk7_27 a b raw seedStart) = chunk422_28 a b raw seedStart := by
    kernel_exact cut422_28 a b raw seedStart
  have h29 : Task2.Imported.BaselineCore.c2lChunk29 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk5_23 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk1_26 a b raw seedStart) (chunk7_27 a b raw seedStart) (chunk422_28 a b raw seedStart) = chunk5_29 a b raw seedStart := by
    kernel_exact cut426_29 a b raw seedStart
  have h30 : Task2.Imported.BaselineCore.c2lChunk30 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk422_21 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk5_23 a b raw seedStart) (chunk1_26 a b raw seedStart) (chunk5_29 a b raw seedStart) = chunk10_30 a b raw seedStart := by
    kernel_exact cut11_30 a b raw seedStart
  have h31 : Task2.Imported.BaselineCore.c2lChunk31 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk5_23 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk7_27 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk10_30 a b raw seedStart) = chunk424_31 a b raw seedStart := by
    kernel_exact cut426_31 a b raw seedStart
  have h32 : Task2.Imported.BaselineCore.c2lChunk32 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk430_17 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk5_23 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk422_28 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk424_31 a b raw seedStart) = chunk424_32 a b raw seedStart := by
    kernel_exact cut424_32 a b raw seedStart
  have h33 : Task2.Imported.BaselineCore.c2lChunk33 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk7_27 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk424_32 a b raw seedStart) = chunk1_33 a b raw seedStart := by
    kernel_exact cut4_33 a b raw seedStart
  have h34 : Task2.Imported.BaselineCore.c2lChunk34 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk4_18 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk7_27 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk424_31 a b raw seedStart) (chunk424_32 a b raw seedStart) (chunk1_33 a b raw seedStart) = chunk1_34 a b raw seedStart := by
    kernel_exact cut4_34 a b raw seedStart
  have h35 : Task2.Imported.BaselineCore.c2lChunk35 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk8_2 a b raw seedStart) (chunk9_5 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk424_31 a b raw seedStart) (chunk424_32 a b raw seedStart) (chunk1_34 a b raw seedStart) = chunk425_35 a b raw seedStart := by
    kernel_exact cut425_35 a b raw seedStart
  have h36 : Task2.Imported.BaselineCore.c2lChunk36 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk424_32 a b raw seedStart) (chunk1_33 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk425_35 a b raw seedStart) = chunk424_36 a b raw seedStart := by
    kernel_exact cut424_36 a b raw seedStart
  have h37 : Task2.Imported.BaselineCore.c2lChunk37 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk430_19 a b raw seedStart) (chunk423_20 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk1_25 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk425_35 a b raw seedStart) (chunk424_36 a b raw seedStart) = chunk430_37 a b raw seedStart := by
    kernel_exact cut430_37 a b raw seedStart
  have h38 : Task2.Imported.BaselineCore.c2lChunk38 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk427_12 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk430_37 a b raw seedStart) = chunk430_38 a b raw seedStart := by
    kernel_exact cut430_38 a b raw seedStart
  have h39 : Task2.Imported.BaselineCore.c2lChunk39 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_12 a b raw seedStart) (chunk430_38 a b raw seedStart) = chunk414_39 a b raw seedStart := by
    kernel_exact cut425_39 a b raw seedStart
  have h40 : Task2.Imported.BaselineCore.c2lChunk40 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_12 a b raw seedStart) (chunk430_38 a b raw seedStart) (chunk414_39 a b raw seedStart) = chunk425_40 a b raw seedStart := by
    kernel_exact cut425_40 a b raw seedStart
  have h41 : Task2.Imported.BaselineCore.c2lChunk41 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_12 a b raw seedStart) (chunk430_38 a b raw seedStart) (chunk425_40 a b raw seedStart) = chunk425_41 a b raw seedStart := by
    kernel_exact cut425_41 a b raw seedStart
  have h42 : Task2.Imported.BaselineCore.c2lChunk42 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_1 a b raw seedStart) (chunk427_12 a b raw seedStart) (chunk428_22 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk430_37 a b raw seedStart) (chunk430_38 a b raw seedStart) (chunk425_41 a b raw seedStart) = chunk430_42 a b raw seedStart := by
    kernel_exact cut430_42 a b raw seedStart
  have h43 : Task2.Imported.BaselineCore.c2lChunk43 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_12 a b raw seedStart) (chunk5_29 a b raw seedStart) (chunk430_37 a b raw seedStart) (chunk430_38 a b raw seedStart) (chunk430_42 a b raw seedStart) = chunk430_43 a b raw seedStart := by
    kernel_exact cut430_43 a b raw seedStart
  have h44 : Task2.Imported.BaselineCore.c2lChunk44 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk430_37 a b raw seedStart) (chunk430_42 a b raw seedStart) (chunk430_43 a b raw seedStart) = chunk427_44 a b raw seedStart := by
    kernel_exact cut428_44 a b raw seedStart
  have h45 : Task2.Imported.BaselineCore.c2lChunk45 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk430_38 a b raw seedStart) (chunk430_42 a b raw seedStart) (chunk430_43 a b raw seedStart) (chunk427_44 a b raw seedStart) = chunk428_45 a b raw seedStart := by
    kernel_exact cut430_45 a b raw seedStart
  have h46 : Task2.Imported.BaselineCore.c2lChunk46 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk430_38 a b raw seedStart) (chunk430_42 a b raw seedStart) (chunk430_43 a b raw seedStart) (chunk427_44 a b raw seedStart) (chunk428_45 a b raw seedStart) = chunk430_46 a b raw seedStart := by
    kernel_exact cut430_46 a b raw seedStart
  have h47 : Task2.Imported.BaselineCore.c2lChunk47 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_44 a b raw seedStart) (chunk428_45 a b raw seedStart) (chunk430_46 a b raw seedStart) = chunk420_47 a b raw seedStart := by
    kernel_exact cut420_47 a b raw seedStart
  have h48 : Task2.Imported.BaselineCore.c2lChunk48 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_44 a b raw seedStart) (chunk430_46 a b raw seedStart) (chunk420_47 a b raw seedStart) = chunk420_48 a b raw seedStart := by
    kernel_exact cut420_48 a b raw seedStart
  have h49 : Task2.Imported.BaselineCore.c2lChunk49 (Task2.Imported.BaselineAdapter.inputs (state430 a b raw seedStart)) (state430 a b raw seedStart).raw (chunk427_0 a b raw seedStart) (chunk427_44 a b raw seedStart) (chunk420_47 a b raw seedStart) (chunk420_48 a b raw seedStart) = chunk421_49 a b raw seedStart := by
    kernel_exact cut422_49 a b raw seedStart
  simp only [Task2.Imported.BaselineAdapter.step, Task2.Imported.BaselineCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43, h44, h45, h46, h47, h48, h49]
  kernel_rfl
#print axioms transition430
end Task2.Imported.BaselineTrace
