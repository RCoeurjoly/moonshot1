import Task2.Imported.BaselineCuts1
import Task2.Imported.BaselineCuts4
import Task2.Imported.BaselineCuts6
import Task2.Imported.BaselineCuts7
import Task2.Imported.BaselineCuts24
import Task2.Imported.BaselineCuts25
import Task2.Imported.BaselineCuts26
import Task2.ProofTools
set_option maxHeartbeats 0
set_option maxRecDepth 65536
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
namespace Task2.Imported.BaselineTrace
theorem transition210 (a b : Task2.Words) (raw : Task2.Imported.BaselineCore.State) (seedStart : Bool) :
    Task2.Imported.BaselineAdapter.step (state210 a b raw seedStart) = state211 a b raw seedStart := by
  have h0 : Task2.Imported.BaselineCore.c2lChunk0 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw  = chunk33_0 a b raw seedStart := by
    kernel_exact cut33_0 a b raw seedStart
  have h1 : Task2.Imported.BaselineCore.c2lChunk1 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) = chunk17_1 a b raw seedStart := by
    kernel_exact cut33_1 a b raw seedStart
  have h2 : Task2.Imported.BaselineCore.c2lChunk2 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) = chunk210_2 a b raw seedStart := by
    kernel_exact cut210_2 a b raw seedStart
  have h3 : Task2.Imported.BaselineCore.c2lChunk3 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) = chunk210_3 a b raw seedStart := by
    kernel_exact cut210_3 a b raw seedStart
  have h4 : Task2.Imported.BaselineCore.c2lChunk4 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) = chunk207_4 a b raw seedStart := by
    kernel_exact cut207_4 a b raw seedStart
  have h5 : Task2.Imported.BaselineCore.c2lChunk5 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk207_4 a b raw seedStart) = chunk31_5 a b raw seedStart := by
    kernel_exact cut32_5 a b raw seedStart
  have h6 : Task2.Imported.BaselineCore.c2lChunk6 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk207_4 a b raw seedStart) (chunk31_5 a b raw seedStart) = chunk207_6 a b raw seedStart := by
    kernel_exact cut207_6 a b raw seedStart
  have h7 : Task2.Imported.BaselineCore.c2lChunk7 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk207_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk207_6 a b raw seedStart) = chunk205_7 a b raw seedStart := by
    kernel_exact cut206_7 a b raw seedStart
  have h8 : Task2.Imported.BaselineCore.c2lChunk8 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk207_4 a b raw seedStart) (chunk207_6 a b raw seedStart) (chunk205_7 a b raw seedStart) = chunk208_8 a b raw seedStart := by
    kernel_exact cut208_8 a b raw seedStart
  have h9 : Task2.Imported.BaselineCore.c2lChunk9 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk207_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk207_6 a b raw seedStart) (chunk208_8 a b raw seedStart) = chunk33_9 a b raw seedStart := by
    kernel_exact cut33_9 a b raw seedStart
  have h10 : Task2.Imported.BaselineCore.c2lChunk10 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk207_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk205_7 a b raw seedStart) (chunk33_9 a b raw seedStart) = chunk208_10 a b raw seedStart := by
    kernel_exact cut208_10 a b raw seedStart
  have h11 : Task2.Imported.BaselineCore.c2lChunk11 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk207_6 a b raw seedStart) (chunk205_7 a b raw seedStart) (chunk208_8 a b raw seedStart) (chunk208_10 a b raw seedStart) = chunk209_11 a b raw seedStart := by
    kernel_exact cut209_11 a b raw seedStart
  have h12 : Task2.Imported.BaselineCore.c2lChunk12 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk207_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk205_7 a b raw seedStart) (chunk208_8 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk209_11 a b raw seedStart) = chunk207_12 a b raw seedStart := by
    kernel_exact cut208_12 a b raw seedStart
  have h13 : Task2.Imported.BaselineCore.c2lChunk13 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk207_6 a b raw seedStart) (chunk205_7 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk207_12 a b raw seedStart) = chunk207_13 a b raw seedStart := by
    kernel_exact cut209_13 a b raw seedStart
  have h14 : Task2.Imported.BaselineCore.c2lChunk14 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk208_8 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk209_11 a b raw seedStart) (chunk207_13 a b raw seedStart) = chunk210_14 a b raw seedStart := by
    kernel_exact cut210_14 a b raw seedStart
  have h15 : Task2.Imported.BaselineCore.c2lChunk15 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk207_12 a b raw seedStart) (chunk207_13 a b raw seedStart) (chunk210_14 a b raw seedStart) = chunk209_15 a b raw seedStart := by
    kernel_exact cut210_15 a b raw seedStart
  have h16 : Task2.Imported.BaselineCore.c2lChunk16 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk207_4 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk207_6 a b raw seedStart) (chunk205_7 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk207_12 a b raw seedStart) (chunk207_13 a b raw seedStart) (chunk209_15 a b raw seedStart) = chunk31_16 a b raw seedStart := by
    kernel_exact cut32_16 a b raw seedStart
  have h17 : Task2.Imported.BaselineCore.c2lChunk17 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk207_13 a b raw seedStart) (chunk31_16 a b raw seedStart) = chunk210_17 a b raw seedStart := by
    kernel_exact cut210_17 a b raw seedStart
  have h18 : Task2.Imported.BaselineCore.c2lChunk18 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk210_3 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk207_13 a b raw seedStart) (chunk210_17 a b raw seedStart) = chunk28_18 a b raw seedStart := by
    kernel_exact cut29_18 a b raw seedStart
  have h19 : Task2.Imported.BaselineCore.c2lChunk19 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk209_11 a b raw seedStart) (chunk210_14 a b raw seedStart) (chunk209_15 a b raw seedStart) (chunk28_18 a b raw seedStart) = chunk210_19 a b raw seedStart := by
    kernel_exact cut210_19 a b raw seedStart
  have h20 : Task2.Imported.BaselineCore.c2lChunk20 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk207_12 a b raw seedStart) (chunk209_15 a b raw seedStart) (chunk210_17 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk210_19 a b raw seedStart) = chunk199_20 a b raw seedStart := by
    kernel_exact cut210_20 a b raw seedStart
  have h21 : Task2.Imported.BaselineCore.c2lChunk21 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk207_13 a b raw seedStart) (chunk210_17 a b raw seedStart) (chunk199_20 a b raw seedStart) = chunk35_21 a b raw seedStart := by
    kernel_exact cut35_21 a b raw seedStart
  have h22 : Task2.Imported.BaselineCore.c2lChunk22 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk207_13 a b raw seedStart) (chunk210_17 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk35_21 a b raw seedStart) = chunk209_22 a b raw seedStart := by
    kernel_exact cut210_22 a b raw seedStart
  have h23 : Task2.Imported.BaselineCore.c2lChunk23 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk209_15 a b raw seedStart) (chunk210_17 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk35_21 a b raw seedStart) (chunk209_22 a b raw seedStart) = chunk35_23 a b raw seedStart := by
    kernel_exact cut35_23 a b raw seedStart
  have h24 : Task2.Imported.BaselineCore.c2lChunk24 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk210_14 a b raw seedStart) (chunk209_15 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk35_23 a b raw seedStart) = chunk210_24 a b raw seedStart := by
    kernel_exact cut210_24 a b raw seedStart
  have h25 : Task2.Imported.BaselineCore.c2lChunk25 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk210_17 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk210_24 a b raw seedStart) = chunk15_25 a b raw seedStart := by
    kernel_exact cut16_25 a b raw seedStart
  have h26 : Task2.Imported.BaselineCore.c2lChunk26 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk208_10 a b raw seedStart) (chunk210_17 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk35_21 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk15_25 a b raw seedStart) = chunk29_26 a b raw seedStart := by
    kernel_exact cut30_26 a b raw seedStart
  have h27 : Task2.Imported.BaselineCore.c2lChunk27 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk210_17 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk35_21 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk35_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk29_26 a b raw seedStart) = chunk209_27 a b raw seedStart := by
    kernel_exact cut210_27 a b raw seedStart
  have h28 : Task2.Imported.BaselineCore.c2lChunk28 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk33_9 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk35_23 a b raw seedStart) (chunk210_24 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk209_27 a b raw seedStart) = chunk208_28 a b raw seedStart := by
    kernel_exact cut209_28 a b raw seedStart
  have h29 : Task2.Imported.BaselineCore.c2lChunk29 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk35_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk29_26 a b raw seedStart) (chunk209_27 a b raw seedStart) (chunk208_28 a b raw seedStart) = chunk15_29 a b raw seedStart := by
    kernel_exact cut16_29 a b raw seedStart
  have h30 : Task2.Imported.BaselineCore.c2lChunk30 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk35_21 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk35_23 a b raw seedStart) (chunk29_26 a b raw seedStart) (chunk15_29 a b raw seedStart) = chunk27_30 a b raw seedStart := by
    kernel_exact cut28_30 a b raw seedStart
  have h31 : Task2.Imported.BaselineCore.c2lChunk31 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk35_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk209_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk27_30 a b raw seedStart) = chunk209_31 a b raw seedStart := by
    kernel_exact cut210_31 a b raw seedStart
  have h32 : Task2.Imported.BaselineCore.c2lChunk32 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk210_17 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk35_23 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk208_28 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk209_31 a b raw seedStart) = chunk197_32 a b raw seedStart := by
    kernel_exact cut197_32 a b raw seedStart
  have h33 : Task2.Imported.BaselineCore.c2lChunk33 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk209_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk197_32 a b raw seedStart) = chunk16_33 a b raw seedStart := by
    kernel_exact cut17_33 a b raw seedStart
  have h34 : Task2.Imported.BaselineCore.c2lChunk34 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk28_18 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk209_27 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk209_31 a b raw seedStart) (chunk197_32 a b raw seedStart) (chunk16_33 a b raw seedStart) = chunk1_34 a b raw seedStart := by
    kernel_exact cut4_34 a b raw seedStart
  have h35 : Task2.Imported.BaselineCore.c2lChunk35 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_2 a b raw seedStart) (chunk31_5 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk209_31 a b raw seedStart) (chunk197_32 a b raw seedStart) (chunk1_34 a b raw seedStart) = chunk197_35 a b raw seedStart := by
    kernel_exact cut209_35 a b raw seedStart
  have h36 : Task2.Imported.BaselineCore.c2lChunk36 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk197_32 a b raw seedStart) (chunk16_33 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk197_35 a b raw seedStart) = chunk196_36 a b raw seedStart := by
    kernel_exact cut197_36 a b raw seedStart
  have h37 : Task2.Imported.BaselineCore.c2lChunk37 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk210_19 a b raw seedStart) (chunk199_20 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk15_25 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk197_35 a b raw seedStart) (chunk196_36 a b raw seedStart) = chunk201_37 a b raw seedStart := by
    kernel_exact cut202_37 a b raw seedStart
  have h38 : Task2.Imported.BaselineCore.c2lChunk38 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk207_12 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk201_37 a b raw seedStart) = chunk198_38 a b raw seedStart := by
    kernel_exact cut198_38 a b raw seedStart
  have h39 : Task2.Imported.BaselineCore.c2lChunk39 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk207_12 a b raw seedStart) (chunk198_38 a b raw seedStart) = chunk189_39 a b raw seedStart := by
    kernel_exact cut198_39 a b raw seedStart
  have h40 : Task2.Imported.BaselineCore.c2lChunk40 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk207_12 a b raw seedStart) (chunk198_38 a b raw seedStart) (chunk189_39 a b raw seedStart) = chunk198_40 a b raw seedStart := by
    kernel_exact cut198_40 a b raw seedStart
  have h41 : Task2.Imported.BaselineCore.c2lChunk41 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk207_12 a b raw seedStart) (chunk198_38 a b raw seedStart) (chunk198_40 a b raw seedStart) = chunk198_41 a b raw seedStart := by
    kernel_exact cut198_41 a b raw seedStart
  have h42 : Task2.Imported.BaselineCore.c2lChunk42 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk17_1 a b raw seedStart) (chunk207_12 a b raw seedStart) (chunk209_22 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk1_34 a b raw seedStart) (chunk201_37 a b raw seedStart) (chunk198_38 a b raw seedStart) (chunk198_41 a b raw seedStart) = chunk189_42 a b raw seedStart := by
    kernel_exact cut199_42 a b raw seedStart
  have h43 : Task2.Imported.BaselineCore.c2lChunk43 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk207_12 a b raw seedStart) (chunk15_29 a b raw seedStart) (chunk201_37 a b raw seedStart) (chunk198_38 a b raw seedStart) (chunk189_42 a b raw seedStart) = chunk191_43 a b raw seedStart := by
    kernel_exact cut191_43 a b raw seedStart
  have h44 : Task2.Imported.BaselineCore.c2lChunk44 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk201_37 a b raw seedStart) (chunk189_42 a b raw seedStart) (chunk191_43 a b raw seedStart) = chunk192_44 a b raw seedStart := by
    kernel_exact cut192_44 a b raw seedStart
  have h45 : Task2.Imported.BaselineCore.c2lChunk45 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk198_38 a b raw seedStart) (chunk189_42 a b raw seedStart) (chunk191_43 a b raw seedStart) (chunk192_44 a b raw seedStart) = chunk193_45 a b raw seedStart := by
    kernel_exact cut193_45 a b raw seedStart
  have h46 : Task2.Imported.BaselineCore.c2lChunk46 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk198_38 a b raw seedStart) (chunk189_42 a b raw seedStart) (chunk191_43 a b raw seedStart) (chunk192_44 a b raw seedStart) (chunk193_45 a b raw seedStart) = chunk192_46 a b raw seedStart := by
    kernel_exact cut192_46 a b raw seedStart
  have h47 : Task2.Imported.BaselineCore.c2lChunk47 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk192_44 a b raw seedStart) (chunk193_45 a b raw seedStart) (chunk192_46 a b raw seedStart) = chunk195_47 a b raw seedStart := by
    kernel_exact cut195_47 a b raw seedStart
  have h48 : Task2.Imported.BaselineCore.c2lChunk48 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk192_44 a b raw seedStart) (chunk192_46 a b raw seedStart) (chunk195_47 a b raw seedStart) = chunk195_48 a b raw seedStart := by
    kernel_exact cut195_48 a b raw seedStart
  have h49 : Task2.Imported.BaselineCore.c2lChunk49 (Task2.Imported.BaselineAdapter.inputs (state210 a b raw seedStart)) (state210 a b raw seedStart).raw (chunk33_0 a b raw seedStart) (chunk192_44 a b raw seedStart) (chunk195_47 a b raw seedStart) (chunk195_48 a b raw seedStart) = chunk196_49 a b raw seedStart := by
    kernel_exact cut197_49 a b raw seedStart
  simp only [Task2.Imported.BaselineAdapter.step, Task2.Imported.BaselineCore.evaluate, h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15, h16, h17, h18, h19, h20, h21, h22, h23, h24, h25, h26, h27, h28, h29, h30, h31, h32, h33, h34, h35, h36, h37, h38, h39, h40, h41, h42, h43, h44, h45, h46, h47, h48, h49]
  kernel_rfl
#print axioms transition210
end Task2.Imported.BaselineTrace
